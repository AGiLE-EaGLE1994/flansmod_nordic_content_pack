//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: KarlXIITunic
// Model Creator: 
// Created on: 10.03.2020 - 11:17:29
// Last changed on: 10.03.2020 - 11:17:29

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.ModelCustomArmour;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelKarlXIITunic extends ModelCustomArmour //Same as Filename
{
	int textureX = 64;
	int textureY = 32;

	public ModelKarlXIITunic() //Same as Filename
	{
		bodyModel = new ModelRendererTurbo[2];
		bodyModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // torso
		bodyModel[1] = new ModelRendererTurbo(this, 24, 0, textureX, textureY); // belt

		bodyModel[0].addShapeBox(-4F, 0.75F, -2F, 8, 15, 4, 0F, 0.75F, 0.75F, 0.75F, 0.75F, 0.75F, 0.75F, 0.75F, 0.75F, 0.75F, 0.75F, 0.75F, 0.75F, 0.75F, -7F, 0.75F, 0.75F, -7F, 0.75F, 0.75F, -7F, 0.75F, 0.75F, -7F, 0.75F); // torso
		bodyModel[0].setRotationPoint(0F, 0F, 0F);

		bodyModel[1].addShapeBox(-4F, 9F, -2F, 8, 5, 4, 0F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, -2F, 0.25F, 0.25F, -2F, 0.25F, 0.25F, -2F, 0.25F, 0.25F, -2F, 0.25F); // belt
		bodyModel[1].setRotationPoint(0F, 0F, 0F);


		leftArmModel = new ModelRendererTurbo[1];
		leftArmModel[0] = new ModelRendererTurbo(this, 0, 21, textureX, textureY); // Box 9

		leftArmModel[0].addBox(-1F, -2F, -2F, 4, 7, 4, 0F); // Box 9
		leftArmModel[0].setRotationPoint(0F, 0F, 0F);


		rightArmModel = new ModelRendererTurbo[1];
		rightArmModel[0] = new ModelRendererTurbo(this, 0, 21, textureX, textureY); // Box 8

		rightArmModel[0].addBox(-3F, -2F, -2F, 4, 7, 4, 0F); // Box 8
		rightArmModel[0].setRotationPoint(0F, 0F, 0F);


		leftLegModel = new ModelRendererTurbo[1];
		leftLegModel[0] = new ModelRendererTurbo(this, 19, 24, textureX, textureY); // Box 5

		leftLegModel[0].addBox(0F, 0F, -2F, 1, 1, 1, 0F); // Box 5
		leftLegModel[0].setRotationPoint(0F, 0F, 0F);


		rightLegModel = new ModelRendererTurbo[1];
		rightLegModel[0] = new ModelRendererTurbo(this, 19, 24, textureX, textureY); // Box 6

		rightLegModel[0].addBox(0F, 0F, -2F, 1, 1, 1, 0F); // Box 6
		rightLegModel[0].setRotationPoint(0F, 0F, 0F);


	}
}