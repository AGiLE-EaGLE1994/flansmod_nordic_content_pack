//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: CaroleanCannon
// Model Creator: 
// Created on: 05.01.2016 - 10:21:11
// Last changed on: 05.01.2016 - 10:21:11

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.ModelAAGun;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelCaroleanCannon extends ModelAAGun //Same as Filename
{
	int textureX = 128;
	int textureY = 128;

	public ModelCaroleanCannon() //Same as Filename
	{
		seatModel = new ModelRendererTurbo[47];
		seatModel[0] = new ModelRendererTurbo(this, 6, 29, textureX, textureY); // Box 1
		seatModel[1] = new ModelRendererTurbo(this, 69, 91, textureX, textureY); // Box 8
		seatModel[2] = new ModelRendererTurbo(this, 0, 88, textureX, textureY); // Box 9
		seatModel[3] = new ModelRendererTurbo(this, 69, 103, textureX, textureY); // Box 10
		seatModel[4] = new ModelRendererTurbo(this, 0, 100, textureX, textureY); // Box 11
		seatModel[5] = new ModelRendererTurbo(this, 77, 71, textureX, textureY); // Box 12
		seatModel[6] = new ModelRendererTurbo(this, 77, 79, textureX, textureY); // Box 13
		seatModel[7] = new ModelRendererTurbo(this, 42, 48, textureX, textureY); // Box 14
		seatModel[8] = new ModelRendererTurbo(this, 6, 33, textureX, textureY); // Box 16
		seatModel[9] = new ModelRendererTurbo(this, 39, 68, textureX, textureY); // Box 19
		seatModel[10] = new ModelRendererTurbo(this, 2, 68, textureX, textureY); // Box 20
		seatModel[11] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Import WBL10
		seatModel[12] = new ModelRendererTurbo(this, 6, 43, textureX, textureY); // Import WBL13
		seatModel[13] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Import WBL17
		seatModel[14] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 56
		seatModel[15] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 58
		seatModel[16] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 59
		seatModel[17] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 60
		seatModel[18] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 62
		seatModel[19] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 63
		seatModel[20] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 65
		seatModel[21] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 70
		seatModel[22] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 71
		seatModel[23] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 72
		seatModel[24] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 73
		seatModel[25] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 74
		seatModel[26] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 75
		seatModel[27] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 76
		seatModel[28] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 94
		seatModel[29] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 95
		seatModel[30] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 96
		seatModel[31] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 97
		seatModel[32] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 98
		seatModel[33] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 99
		seatModel[34] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 100
		seatModel[35] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 101
		seatModel[36] = new ModelRendererTurbo(this, 33, 52, textureX, textureY); // Box 102
		seatModel[37] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 103
		seatModel[38] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 104
		seatModel[39] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 105
		seatModel[40] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 106
		seatModel[41] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 107
		seatModel[42] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 108
		seatModel[43] = new ModelRendererTurbo(this, 9, 57, textureX, textureY); // Box 109
		seatModel[44] = new ModelRendererTurbo(this, 6, 43, textureX, textureY); // Shape 110
		seatModel[45] = new ModelRendererTurbo(this, 22, 48, textureX, textureY); // Box 54
		seatModel[46] = new ModelRendererTurbo(this, 22, 48, textureX, textureY); // Box 55

		seatModel[0].addBox(-0.5F, -0.5F, -6F, 2, 2, 12, 0F); // Box 1
		seatModel[0].setRotationPoint(0F, -16.5F, 0F);

		seatModel[1].addShapeBox(-12F, -2F, -7F, 16, 6, 2, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 2F, 4F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 4F, 0F); // Box 8
		seatModel[1].setRotationPoint(0F, -16.5F, 0F);

		seatModel[2].addShapeBox(-44F, -1F, -7F, 32, 9, 2, 0F, 0F, -12F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -12F, 0F, 0F, 8F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 8F, 0F); // Box 9
		seatModel[2].setRotationPoint(0F, -16.5F, 0F);

		seatModel[3].addShapeBox(-12F, -2F, 6F, 16, 6, 2, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 2F, 4F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 4F, 0F); // Box 10
		seatModel[3].setRotationPoint(0F, -16.5F, 0F);

		seatModel[4].addShapeBox(-44F, -1F, 6F, 32, 9, 2, 0F, 0F, -12F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -12F, 0F, 0F, 8F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 8F, 0F); // Box 11
		seatModel[4].setRotationPoint(0F, -16.5F, 0F);

		seatModel[5].addBox(2F, 0F, 0F, 10, 5, 2, 0F); // Box 12
		seatModel[5].setRotationPoint(-56F, -5.5F, -7F);

		seatModel[6].addBox(2F, 0F, 0F, 10, 5, 2, 0F); // Box 13
		seatModel[6].setRotationPoint(-56F, -5.5F, 6F);

		seatModel[7].addBox(3F, 0F, 0F, 8, 2, 11, 0F); // Box 14
		seatModel[7].setRotationPoint(-56F, -4.5F, -5F);

		seatModel[8].addBox(-0.5F, -0.75F, -16F, 1, 1, 32, 0F); // Box 16
		seatModel[8].setRotationPoint(-1F, -10.5F, 0F);

		seatModel[9].addTrapezoid(-3F, -8F, 0F, 6, 6, 12, 0F, -2.00F, ModelRendererTurbo.MR_FRONT); // Box 19
		seatModel[9].setRotationPoint(-1F, -5.5F, -28F);

		seatModel[10].addTrapezoid(-3F, -3F, 0F, 6, 6, 12, 0F, -2.00F, ModelRendererTurbo.MR_BACK); // Box 20
		seatModel[10].setRotationPoint(-1F, -10.5F, 16F);

		seatModel[11].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.25F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Import WBL10
		seatModel[11].setRotationPoint(-1F, -11F, 15F);

		seatModel[12].addShape3D(1.5F, -1.5F, -5F, new Shape2D(new Coord2D[] { new Coord2D(1, 0, 1, 0), new Coord2D(2, 0, 2, 0), new Coord2D(3, 1, 3, 1), new Coord2D(3, 2, 3, 2), new Coord2D(2, 3, 2, 3), new Coord2D(1, 3, 1, 3), new Coord2D(0, 2, 0, 2), new Coord2D(0, 1, 0, 1) }), 1, 3, 3, 12, 1, ModelRendererTurbo.MR_FRONT, new float[] {2 ,1 ,2 ,1 ,2 ,1 ,2 ,1}); // Import WBL13
		seatModel[12].setRotationPoint(-1F, -11F, 10F);

		seatModel[13].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Import WBL17
		seatModel[13].setRotationPoint(-1F, -11F, 12.5F);

		seatModel[14].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 56
		seatModel[14].setRotationPoint(-1F, -11F, 12.5F);
		seatModel[14].rotateAngleZ = 0.78539816F;

		seatModel[15].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 58
		seatModel[15].setRotationPoint(-1F, -11F, 12.5F);
		seatModel[15].rotateAngleZ = 1.57079633F;

		seatModel[16].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 59
		seatModel[16].setRotationPoint(-1F, -11F, 12.5F);
		seatModel[16].rotateAngleZ = 2.35619449F;

		seatModel[17].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 60
		seatModel[17].setRotationPoint(-1F, -11F, 12.5F);
		seatModel[17].rotateAngleZ = 3.14159265F;

		seatModel[18].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 62
		seatModel[18].setRotationPoint(-1F, -11F, 12.5F);
		seatModel[18].rotateAngleZ = 3.92699082F;

		seatModel[19].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 63
		seatModel[19].setRotationPoint(-1F, -11F, 12.5F);
		seatModel[19].rotateAngleZ = 4.71238898F;

		seatModel[20].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 65
		seatModel[20].setRotationPoint(-1F, -11F, 12.5F);
		seatModel[20].rotateAngleZ = 5.49778714F;

		seatModel[21].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 70
		seatModel[21].setRotationPoint(-1F, -11F, 15F);
		seatModel[21].rotateAngleZ = 0.78539816F;

		seatModel[22].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.25F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 71
		seatModel[22].setRotationPoint(-1F, -11F, 15F);
		seatModel[22].rotateAngleZ = 1.57079633F;

		seatModel[23].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 72
		seatModel[23].setRotationPoint(-1F, -11F, 15F);
		seatModel[23].rotateAngleZ = 2.35619449F;

		seatModel[24].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.25F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 73
		seatModel[24].setRotationPoint(-1F, -11F, 15F);
		seatModel[24].rotateAngleZ = 3.14159265F;

		seatModel[25].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 74
		seatModel[25].setRotationPoint(-1F, -11F, 15F);
		seatModel[25].rotateAngleZ = 3.92699082F;

		seatModel[26].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.25F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 75
		seatModel[26].setRotationPoint(-1F, -11F, 15F);
		seatModel[26].rotateAngleZ = 4.71238898F;

		seatModel[27].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 76
		seatModel[27].setRotationPoint(-1F, -11F, 15F);
		seatModel[27].rotateAngleZ = 5.49778714F;

		seatModel[28].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.25F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 94
		seatModel[28].setRotationPoint(-1F, -11F, -14F);

		seatModel[29].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 95
		seatModel[29].setRotationPoint(-1F, -11F, -16.5F);

		seatModel[30].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 96
		seatModel[30].setRotationPoint(-1F, -11F, -16.5F);
		seatModel[30].rotateAngleZ = 0.78539816F;

		seatModel[31].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 97
		seatModel[31].setRotationPoint(-1F, -11F, -16.5F);
		seatModel[31].rotateAngleZ = 1.57079633F;

		seatModel[32].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 98
		seatModel[32].setRotationPoint(-1F, -11F, -16.5F);
		seatModel[32].rotateAngleZ = 2.35619449F;

		seatModel[33].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 99
		seatModel[33].setRotationPoint(-1F, -11F, -16.5F);
		seatModel[33].rotateAngleZ = 3.14159265F;

		seatModel[34].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 100
		seatModel[34].setRotationPoint(-1F, -11F, -16.5F);
		seatModel[34].rotateAngleZ = 3.92699082F;

		seatModel[35].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 101
		seatModel[35].setRotationPoint(-1F, -11F, -16.5F);
		seatModel[35].rotateAngleZ = 4.71238898F;

		seatModel[36].addShapeBox(-0.5F, 0F, 1.5F, 1, 11, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 102
		seatModel[36].setRotationPoint(-1F, -11F, -16.5F);
		seatModel[36].rotateAngleZ = 5.49778714F;

		seatModel[37].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 103
		seatModel[37].setRotationPoint(-1F, -11F, -14F);
		seatModel[37].rotateAngleZ = 0.78539816F;

		seatModel[38].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.25F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 104
		seatModel[38].setRotationPoint(-1F, -11F, -14F);
		seatModel[38].rotateAngleZ = 1.57079633F;

		seatModel[39].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 105
		seatModel[39].setRotationPoint(-1F, -11F, -14F);
		seatModel[39].rotateAngleZ = 2.35619449F;

		seatModel[40].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.25F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 106
		seatModel[40].setRotationPoint(-1F, -11F, -14F);
		seatModel[40].rotateAngleZ = 3.14159265F;

		seatModel[41].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 107
		seatModel[41].setRotationPoint(-1F, -11F, -14F);
		seatModel[41].rotateAngleZ = 3.92699082F;

		seatModel[42].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.25F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 108
		seatModel[42].setRotationPoint(-1F, -11F, -14F);
		seatModel[42].rotateAngleZ = 4.71238898F;

		seatModel[43].addShapeBox(-5F, 10F, -1F, 10, 2, 1, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 109
		seatModel[43].setRotationPoint(-1F, -11F, -14F);
		seatModel[43].rotateAngleZ = 5.49778714F;

		seatModel[44].addShape3D(1.5F, -1.5F, -5F, new Shape2D(new Coord2D[] { new Coord2D(1, 0, 1, 0), new Coord2D(2, 0, 2, 0), new Coord2D(3, 1, 3, 1), new Coord2D(3, 2, 3, 2), new Coord2D(2, 3, 2, 3), new Coord2D(1, 3, 1, 3), new Coord2D(0, 2, 0, 2), new Coord2D(0, 1, 0, 1) }), 1, 3, 3, 12, 1, ModelRendererTurbo.MR_FRONT, new float[] {2 ,1 ,2 ,1 ,2 ,1 ,2 ,1}); // Shape 110
		seatModel[44].setRotationPoint(-1F, -11F, -19F);

		seatModel[45].addShapeBox(0F, 0F, -1F, 6, 1, 2, 0F, 0F, 0F, -0.25F, 0F, 1.25F, -0.25F, 0F, 1.25F, -0.25F, 0F, 0F, -0.25F, -2F, 0F, -0.25F, -1.5F, -0.5F, -0.25F, -1.5F, -0.5F, -0.25F, -2F, 0F, -0.25F); // Box 54
		seatModel[45].setRotationPoint(-4F, -10.75F, -6F);

		seatModel[46].addShapeBox(0F, 0F, -1F, 6, 1, 2, 0F, 0F, 0F, -0.25F, 0F, 1.25F, -0.25F, 0F, 1.25F, -0.25F, 0F, 0F, -0.25F, -2F, 0F, -0.25F, -1.5F, -0.5F, -0.25F, -1.5F, -0.5F, -0.25F, -2F, 0F, -0.25F); // Box 55
		seatModel[46].setRotationPoint(-4F, -10.75F, 7F);


		barrelModel = new ModelRendererTurbo[1][8];
		barrelModel[0][0] = new ModelRendererTurbo(this, 0, 112, textureX, textureY); // Import 
		barrelModel[0][1] = new ModelRendererTurbo(this, 107, 102, textureX, textureY); // Box 0
		barrelModel[0][2] = new ModelRendererTurbo(this, 30, 67, textureX, textureY); // Box 2
		barrelModel[0][3] = new ModelRendererTurbo(this, 42, 51, textureX, textureY); // Box 3
		barrelModel[0][4] = new ModelRendererTurbo(this, 109, 89, textureX, textureY); // Box 4
		barrelModel[0][5] = new ModelRendererTurbo(this, 109, 82, textureX, textureY); // Box 5
		barrelModel[0][6] = new ModelRendererTurbo(this, 109, 76, textureX, textureY); // Box 6
		barrelModel[0][7] = new ModelRendererTurbo(this, 109, 96, textureX, textureY); // Box 7

		barrelModel[0][0].addTrapezoid(-17F, 0F, -4F, 47, 8, 8, 0F, -1.00F, ModelRendererTurbo.MR_LEFT); // Import 
		barrelModel[0][0].setRotationPoint(0F, 0F, 0F);

		barrelModel[0][1].addTrapezoid(-19F, 0F, -4F, 2, 8, 8, 0F, -1.00F, ModelRendererTurbo.MR_RIGHT); // Box 0
		barrelModel[0][1].setRotationPoint(0F, 0F, 0F);

		barrelModel[0][2].addTrapezoid(-21F, 1F, -3F, 2, 6, 6, 0F, -2.00F, ModelRendererTurbo.MR_RIGHT); // Box 2
		barrelModel[0][2].setRotationPoint(0F, 0F, 0F);
		barrelModel[0][2].rotateAngleZ = 0.01745329F;

		barrelModel[0][3].addTrapezoid(-21.5F, 2.5F, -1.5F, 1, 3, 3, 0F, 0.50F, ModelRendererTurbo.MR_RIGHT); // Box 3
		barrelModel[0][3].setRotationPoint(0F, 0F, 0F);
		barrelModel[0][3].rotateAngleZ = 0.01745329F;

		barrelModel[0][4].addTrapezoid(-26F, 4F, -2F, 4, 2, 4, 0F, 0.50F, ModelRendererTurbo.MR_TOP); // Box 4
		barrelModel[0][4].setRotationPoint(0F, 0F, 0F);
		barrelModel[0][4].rotateAngleZ = 0.01745329F;

		barrelModel[0][5].addTrapezoid(-26F, 2F, -2F, 4, 2, 4, 0F, 0.50F, ModelRendererTurbo.MR_BOTTOM); // Box 5
		barrelModel[0][5].setRotationPoint(0F, 0F, 0F);
		barrelModel[0][5].rotateAngleZ = 0.01745329F;

		barrelModel[0][6].addTrapezoid(-26F, 1F, -2F, 4, 1, 4, 0F, -1.00F, ModelRendererTurbo.MR_TOP); // Box 6
		barrelModel[0][6].setRotationPoint(0F, 0F, 0F);
		barrelModel[0][6].rotateAngleZ = 0.01745329F;

		barrelModel[0][7].addTrapezoid(-26F, 6F, -2F, 4, 1, 4, 0F, -1.00F, ModelRendererTurbo.MR_BOTTOM); // Box 7
		barrelModel[0][7].setRotationPoint(0F, 0F, 0F);
		barrelModel[0][7].rotateAngleZ = 0.01745329F;



		barrelX = 0;
		barrelY = 20;
		barrelZ = 0;


		flipAll();
	}
}