//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: SledCannon
// Model Creator: 
// Created on: 05.01.2016 - 10:21:11
// Last changed on: 05.01.2016 - 10:21:11

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.ModelVehicle;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelSledCannon extends ModelVehicle //Same as Filename
{
	int textureX = 256;
	int textureY = 256;

	public ModelSledCannon() //Same as Filename
	{
		bodyModel = new ModelRendererTurbo[10];
		bodyModel[0] = new ModelRendererTurbo(this, 208, 95, textureX, textureY); // Shape 87
		bodyModel[1] = new ModelRendererTurbo(this, 226, 89, textureX, textureY); // Shape 90
		bodyModel[2] = new ModelRendererTurbo(this, 3, 201, textureX, textureY); // Box 94
		bodyModel[3] = new ModelRendererTurbo(this, 60, 209, textureX, textureY); // Box 95
		bodyModel[4] = new ModelRendererTurbo(this, 190, 110, textureX, textureY); // Box 98
		bodyModel[5] = new ModelRendererTurbo(this, 190, 128, textureX, textureY); // Box 99
		bodyModel[6] = new ModelRendererTurbo(this, 217, 111, textureX, textureY); // Box 100
		bodyModel[7] = new ModelRendererTurbo(this, 218, 128, textureX, textureY); // Box 101
		bodyModel[8] = new ModelRendererTurbo(this, 147, 115, textureX, textureY); // Box 102
		bodyModel[9] = new ModelRendererTurbo(this, 47, 80, textureX, textureY); // Box 103

		bodyModel[0].addShape3D(4F, -4F, -1F, new Shape2D(new Coord2D[] { new Coord2D(2, 8, 2, 8), new Coord2D(0, 6, 0, 6), new Coord2D(0, 2, 0, 2), new Coord2D(2, 0, 2, 0), new Coord2D(6, 0, 6, 0), new Coord2D(8, 2, 8, 2), new Coord2D(8, 6, 8, 6), new Coord2D(6, 8, 6, 8) }), 4, 8, 8, 28, 4, ModelRendererTurbo.MR_FRONT, new float[] {4 ,3 ,4 ,3 ,4 ,3 ,4 ,3}); // Shape 87
		bodyModel[0].setRotationPoint(0F, -37F, -12F);
		bodyModel[0].rotateAngleY = 3.14159265F;

		bodyModel[1].addShape3D(0F, 0F, -1F, new Shape2D(new Coord2D[] { new Coord2D(2, 8, 2, 8), new Coord2D(0, 6, 0, 6), new Coord2D(0, 2, 0, 2), new Coord2D(2, 0, 2, 0), new Coord2D(6, 0, 6, 0), new Coord2D(8, 2, 8, 2), new Coord2D(8, 6, 8, 6), new Coord2D(6, 8, 6, 8) }), 4, 8, 8, 28, 4, ModelRendererTurbo.MR_FRONT, new float[] {4 ,3 ,4 ,3 ,4 ,3 ,4 ,3}); // Shape 90
		bodyModel[1].setRotationPoint(-4F, -33F, 10F);
		bodyModel[1].rotateAngleY = 3.14159265F;

		bodyModel[2].addBox(0F, 0F, -1F, 5, 5, 40, 0F); // Box 94
		bodyModel[2].setRotationPoint(5F, -17F, -19F);

		bodyModel[3].addBox(0F, 0F, -1F, 5, 5, 40, 0F); // Box 95
		bodyModel[3].setRotationPoint(-19F, -17F, -19F);

		bodyModel[4].addShapeBox(0F, 0F, -1F, 8, 12, 4, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, -8F, -1.5F, 0F, -8F, -1.5F, 0F, 8F, -1.5F, 0F, 8F); // Box 98
		bodyModel[4].setRotationPoint(3.5F, -12F, 9F);

		bodyModel[5].addShapeBox(0F, 0F, -1F, 8, 12, 4, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, -8F, -1.5F, 0F, -8F, -1.5F, 0F, 8F, -1.5F, 0F, 8F); // Box 99
		bodyModel[5].setRotationPoint(-20.5F, -12F, 9F);

		bodyModel[6].addShapeBox(0F, 0F, -1F, 8, 12, 4, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 8F, -1.5F, 0F, 8F, -1.5F, 0F, -8F, -1.5F, 0F, -8F); // Box 100
		bodyModel[6].setRotationPoint(-20.5F, -12F, -11F);

		bodyModel[7].addShapeBox(0F, 0F, -1F, 8, 12, 4, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 8F, -1.5F, 0F, 8F, -1.5F, 0F, -8F, -1.5F, 0F, -8F); // Box 101
		bodyModel[7].setRotationPoint(3.5F, -12F, -11F);

		bodyModel[8].addBox(0F, 0F, -1F, 5, 2, 30, 0F); // Box 102
		bodyModel[8].setRotationPoint(-14F, -17F, -14F);

		bodyModel[9].addBox(0F, 0F, -1F, 5, 2, 30, 0F); // Box 103
		bodyModel[9].setRotationPoint(0F, -17F, -14F);


		bodyDoorOpenModel = new ModelRendererTurbo[1];
		bodyDoorOpenModel[0] = new ModelRendererTurbo(this, 0, 68, textureX, textureY); // Box 1

		bodyDoorOpenModel[0].addBox(-2F, -2F, -9F, 4, 4, 18, 0F); // Box 1
		bodyDoorOpenModel[0].setRotationPoint(0F, -37.5F, 0F);


		turretModel = new ModelRendererTurbo[5];
		turretModel[0] = new ModelRendererTurbo(this, 1, 172, textureX, textureY); // Shape 86
		turretModel[1] = new ModelRendererTurbo(this, 1, 36, textureX, textureY); // Box 91
		turretModel[2] = new ModelRendererTurbo(this, 1, 145, textureX, textureY); // Shape 93
		turretModel[3] = new ModelRendererTurbo(this, 4, 2, textureX, textureY); // Box 97
		turretModel[4] = new ModelRendererTurbo(this, 84, 54, textureX, textureY); // Box 104

		turretModel[0].addShape3D(-14F, -4F, -5F, new Shape2D(new Coord2D[] { new Coord2D(8, 20, 8, 20), new Coord2D(2, 16, 2, 16), new Coord2D(0, 8, 0, 8), new Coord2D(1, 0, 1, 0), new Coord2D(56, 0, 56, 0), new Coord2D(56, 20, 56, 20) }), 4, 56, 20, 149, 4, ModelRendererTurbo.MR_FRONT, new float[] {48 ,20 ,55 ,9 ,9 ,8}); // Shape 86
		turretModel[0].setRotationPoint(-56F, -21F, -7F);
		turretModel[0].rotateAngleY = 3.14159265F;

		turretModel[1].addShapeBox(36F, -10F, -1F, 32, 16, 16, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, -6F, 0F, 0F, -6F, 0F, -2F, 0F, -2F, -2F, 0F, -2F, -2F, -6F, 0F, -2F, -6F); // Box 91
		turretModel[1].setRotationPoint(-56F, -21F, 13F);

		turretModel[2].addShape3D(-14F, -4F, 15F, new Shape2D(new Coord2D[] { new Coord2D(8, 20, 8, 20), new Coord2D(2, 16, 2, 16), new Coord2D(0, 8, 0, 8), new Coord2D(1, 0, 1, 0), new Coord2D(56, 0, 56, 0), new Coord2D(56, 20, 56, 20) }), 4, 56, 20, 149, 4, ModelRendererTurbo.MR_FRONT, new float[] {48 ,20 ,55 ,9 ,9 ,8}); // Shape 93
		turretModel[2].setRotationPoint(-56F, -21F, -7F);
		turretModel[2].rotateAngleY = 3.14159265F;

		turretModel[3].addShapeBox(36F, -10F, -15F, 32, 16, 16, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, -6F, 0F, 0F, -6F, 0F, -2F, 0F, -2F, -2F, 0F, -2F, -2F, -6F, 0F, -2F, -6F); // Box 97
		turretModel[3].setRotationPoint(-56F, -21F, -7F);

		turretModel[4].addBox(0F, 0F, -1F, 70, 4, 16, 0F); // Box 104
		turretModel[4].setRotationPoint(-56F, -21F, -7F);


		barrelModel = new ModelRendererTurbo[14];
		barrelModel[0] = new ModelRendererTurbo(this, 1, 118, textureX, textureY); // Import 
		barrelModel[1] = new ModelRendererTurbo(this, 92, 83, textureX, textureY); // Box 0
		barrelModel[2] = new ModelRendererTurbo(this, 0, 90, textureX, textureY); // Box 2
		barrelModel[3] = new ModelRendererTurbo(this, 31, 93, textureX, textureY); // Box 3
		barrelModel[4] = new ModelRendererTurbo(this, 42, 100, textureX, textureY); // Box 4
		barrelModel[5] = new ModelRendererTurbo(this, 53, 91, textureX, textureY); // Box 5
		barrelModel[6] = new ModelRendererTurbo(this, 55, 98, textureX, textureY); // Box 6
		barrelModel[7] = new ModelRendererTurbo(this, 40, 94, textureX, textureY); // Box 7
		barrelModel[8] = new ModelRendererTurbo(this, 25, 101, textureX, textureY); // Box 73
		barrelModel[9] = new ModelRendererTurbo(this, 0, 112, textureX, textureY); // Box 74
		barrelModel[10] = new ModelRendererTurbo(this, 0, 112, textureX, textureY); // Box 75
		barrelModel[11] = new ModelRendererTurbo(this, 0, 112, textureX, textureY); // Box 76
		barrelModel[12] = new ModelRendererTurbo(this, 0, 112, textureX, textureY); // Box 77
		barrelModel[13] = new ModelRendererTurbo(this, 25, 106, textureX, textureY); // Box 78

		barrelModel[0].addTrapezoid(-32F, -6F, -6F, 75, 12, 12, 0F, -1.00F, ModelRendererTurbo.MR_LEFT); // Import 
		barrelModel[0].setRotationPoint(0F, -37F, 0F);
		barrelModel[0].rotateAngleY = 0.01745329F;

		barrelModel[1].addTrapezoid(-34F, -6F, -6F, 2, 12, 12, 0F, -1.00F, ModelRendererTurbo.MR_RIGHT); // Box 0
		barrelModel[1].setRotationPoint(0F, -37F, 0F);
		barrelModel[1].rotateAngleY = 0.01745329F;

		barrelModel[2].addTrapezoid(-36F, -5F, -5F, 2, 10, 10, 0F, -2.00F, ModelRendererTurbo.MR_RIGHT); // Box 2
		barrelModel[2].setRotationPoint(0F, -37F, 0F);
		barrelModel[2].rotateAngleY = 0.01745329F;

		barrelModel[3].addTrapezoid(-37.5F, -2F, -1.5F, 1, 3, 3, 0F, 0.50F, ModelRendererTurbo.MR_RIGHT); // Box 3
		barrelModel[3].setRotationPoint(0F, -37F, 0F);
		barrelModel[3].rotateAngleY = 0.01745329F;
		barrelModel[3].rotateAngleZ = 0.01745329F;

		barrelModel[4].addTrapezoid(-42F, -0.5F, -2F, 4, 2, 4, 0F, 0.50F, ModelRendererTurbo.MR_TOP); // Box 4
		barrelModel[4].setRotationPoint(0F, -37F, 0F);
		barrelModel[4].rotateAngleY = 0.01745329F;
		barrelModel[4].rotateAngleZ = 0.01745329F;

		barrelModel[5].addTrapezoid(-42F, -2.5F, -2F, 4, 2, 4, 0F, 0.50F, ModelRendererTurbo.MR_BOTTOM); // Box 5
		barrelModel[5].setRotationPoint(0F, -37F, 0F);
		barrelModel[5].rotateAngleY = 0.01745329F;
		barrelModel[5].rotateAngleZ = 0.01745329F;

		barrelModel[6].addTrapezoid(-42F, -3.5F, -2F, 4, 1, 4, 0F, -1.00F, ModelRendererTurbo.MR_TOP); // Box 6
		barrelModel[6].setRotationPoint(0F, -37F, 0F);
		barrelModel[6].rotateAngleY = 0.01745329F;
		barrelModel[6].rotateAngleZ = 0.01745329F;

		barrelModel[7].addTrapezoid(-42F, 1.5F, -2F, 4, 1, 4, 0F, -1.00F, ModelRendererTurbo.MR_BOTTOM); // Box 7
		barrelModel[7].setRotationPoint(0F, -37F, 0F);
		barrelModel[7].rotateAngleY = 0.01745329F;
		barrelModel[7].rotateAngleZ = 0.01745329F;

		barrelModel[8].addShapeBox(-15F, -9.5F, -6F, 6, 2, 2, 0F, -0.5F, -0.25F, 0.25F, -0.5F, -0.25F, 0.25F, -0.5F, 0.25F, -0.25F, -0.5F, 0.25F, -0.25F, 0F, 0.25F, -0.25F, 0F, 0.25F, -0.25F, 0F, -0.25F, 0.25F, 0F, -0.25F, 0.25F); // Box 73
		barrelModel[8].setRotationPoint(0F, -37F, 0F);
		barrelModel[8].rotateAngleY = 0.01745329F;

		barrelModel[9].addShapeBox(-15F, -7.5F, -5.5F, 2, 2, 2, 0F, 0F, -0.25F, 0.25F, 0F, -0.25F, 0.25F, 0F, 0.25F, -0.25F, 0F, 0.25F, -0.25F, 0F, 0.25F, -0.5F, 0F, 0.25F, -0.5F, 0F, -0.25F, 0.5F, 0F, -0.25F, 0.5F); // Box 74
		barrelModel[9].setRotationPoint(0F, -37F, 0F);
		barrelModel[9].rotateAngleY = 0.01745329F;

		barrelModel[10].addShapeBox(-11F, -7.5F, -5.5F, 2, 2, 2, 0F, 0F, -0.25F, 0.25F, 0F, -0.25F, 0.25F, 0F, 0.25F, -0.25F, 0F, 0.25F, -0.25F, 0F, 0.25F, -0.5F, 0F, 0.25F, -0.5F, 0F, -0.25F, 0.5F, 0F, -0.25F, 0.5F); // Box 75
		barrelModel[10].setRotationPoint(0F, -37F, 0F);
		barrelModel[10].rotateAngleY = 0.01745329F;

		barrelModel[11].addShapeBox(-11F, -7.5F, 3.5F, 2, 2, 2, 0F, 0F, 0.25F, -0.25F, 0F, 0.25F, -0.25F, 0F, -0.25F, 0.25F, 0F, -0.25F, 0.25F, 0F, -0.25F, 0.5F, 0F, -0.25F, 0.5F, 0F, 0.25F, -0.5F, 0F, 0.25F, -0.5F); // Box 76
		barrelModel[11].setRotationPoint(0F, -37F, 0F);
		barrelModel[11].rotateAngleY = 0.01745329F;

		barrelModel[12].addShapeBox(-15F, -7.5F, 3.5F, 2, 2, 2, 0F, 0F, 0.25F, -0.25F, 0F, 0.25F, -0.25F, 0F, -0.25F, 0.25F, 0F, -0.25F, 0.25F, 0F, -0.25F, 0.5F, 0F, -0.25F, 0.5F, 0F, 0.25F, -0.5F, 0F, 0.25F, -0.5F); // Box 77
		barrelModel[12].setRotationPoint(0F, -37F, 0F);
		barrelModel[12].rotateAngleY = 0.01745329F;

		barrelModel[13].addShapeBox(-15F, -9.5F, 4F, 6, 2, 2, 0F, -0.5F, 0.25F, -0.25F, -0.5F, 0.25F, -0.25F, -0.5F, -0.25F, 0.25F, -0.5F, -0.25F, 0.25F, 0F, -0.25F, 0.25F, 0F, -0.25F, 0.25F, 0F, 0.25F, -0.25F, 0F, 0.25F, -0.25F); // Box 78
		barrelModel[13].setRotationPoint(0F, -37F, 0F);
		barrelModel[13].rotateAngleY = 0.01745329F;


		leftTrackModel = new ModelRendererTurbo[5];
		leftTrackModel[0] = new ModelRendererTurbo(this, 156, 162, textureX, textureY); // Box 111
		leftTrackModel[1] = new ModelRendererTurbo(this, 88, 37, textureX, textureY); // Box 112
		leftTrackModel[2] = new ModelRendererTurbo(this, 157, 149, textureX, textureY); // Box 113
		leftTrackModel[3] = new ModelRendererTurbo(this, 170, 75, textureX, textureY); // Box 114
		leftTrackModel[4] = new ModelRendererTurbo(this, 178, 93, textureX, textureY); // Box 115

		leftTrackModel[0].addShapeBox(0F, 0F, -1F, 12, 8, 4, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, -2F, -4F, -4F, -2F, -4F, -4F, 0F, 0F, -2F, 0F); // Box 111
		leftTrackModel[0].setRotationPoint(32F, 0F, 17F);

		leftTrackModel[1].addShapeBox(0F, 0F, -1F, 74, 8, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, -2F, 0F, -2F, -2F, 0F, -2F, 0F, 0F, -2F, 0F); // Box 112
		leftTrackModel[1].setRotationPoint(-42F, 0F, 17F);

		leftTrackModel[2].addShapeBox(0F, 0F, -1F, 16, 8, 4, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 0F, 0F, -4F, -2F, 0F, -2F, -2F, 0F, -2F, 0F, 0F, -4F, 0F); // Box 113
		leftTrackModel[2].setRotationPoint(-58F, 0F, 17F);

		leftTrackModel[3].addShapeBox(0F, 0F, -1F, 12, 8, 4, 0F, 0F, 6F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 6F, 0F, 0F, -8F, -2F, 0F, -2F, -2F, 0F, -2F, 0F, 0F, -8F, 0F); // Box 114
		leftTrackModel[3].setRotationPoint(-70F, -2F, 17F);

		leftTrackModel[4].addShapeBox(0F, 0F, -1F, 8, 9, 4, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 0F, -2F, -2F, -2F, 0F, -3F, -2F, 0F, -3F, 0F, -2F, -2F, 0F); // Box 115
		leftTrackModel[4].setRotationPoint(-78F, -8F, 17F);


		rightTrackModel = new ModelRendererTurbo[5];
		rightTrackModel[0] = new ModelRendererTurbo(this, 90, 1, textureX, textureY); // Box 105
		rightTrackModel[1] = new ModelRendererTurbo(this, 115, 149, textureX, textureY); // Box 106
		rightTrackModel[2] = new ModelRendererTurbo(this, 198, 162, textureX, textureY); // Box 107
		rightTrackModel[3] = new ModelRendererTurbo(this, 204, 75, textureX, textureY); // Box 108
		rightTrackModel[4] = new ModelRendererTurbo(this, 199, 149, textureX, textureY); // Box 110

		rightTrackModel[0].addShapeBox(0F, 0F, -1F, 74, 8, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, -2F, 0F, -2F, -2F); // Box 105
		rightTrackModel[0].setRotationPoint(-42F, 0F, -19F);

		rightTrackModel[1].addShapeBox(0F, 0F, -1F, 16, 8, 4, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 0F, 0F, -4F, 0F, 0F, -2F, 0F, 0F, -2F, -2F, 0F, -4F, -2F); // Box 106
		rightTrackModel[1].setRotationPoint(-58F, 0F, -19F);

		rightTrackModel[2].addShapeBox(0F, 0F, -1F, 12, 8, 4, 0F, 0F, 6F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 6F, 0F, 0F, -8F, 0F, 0F, -2F, 0F, 0F, -2F, -2F, 0F, -8F, -2F); // Box 107
		rightTrackModel[2].setRotationPoint(-70F, -2F, -19F);

		rightTrackModel[3].addShapeBox(0F, 0F, -1F, 8, 9, 4, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 0F, -2F, -2F, 0F, 0F, -3F, 0F, 0F, -3F, -2F, -2F, -2F, -2F); // Box 108
		rightTrackModel[3].setRotationPoint(-78F, -8F, -19F);

		rightTrackModel[4].addShapeBox(0F, 0F, -1F, 12, 8, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, -2F, 0F, -4F, -4F, 0F, -4F, -4F, -2F, 0F, -2F, -2F); // Box 110
		rightTrackModel[4].setRotationPoint(32F, 0F, -19F);



		translateAll(0F, 0F, 0F);


		flipAll();
	}
}