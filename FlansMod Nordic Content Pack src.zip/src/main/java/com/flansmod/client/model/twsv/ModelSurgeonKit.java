//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: SurgeonKit
// Model Creator:
// Created on:22.04.2020 - 12:12:09
// Last changed on: 22.04.2020 - 12:12:09

package com.flansmod.client.model.twsv;

import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.Entity;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelSurgeonKit extends ModelBase
{
	int textureX = 1024;
	int textureY = 512;

	public ModelSurgeonKit()
	{
		surgeonkitModel = new ModelRendererTurbo[14];
		surgeonkitModel[0] = new ModelRendererTurbo(this, 35, 290, textureX, textureY); // Box 0
		surgeonkitModel[1] = new ModelRendererTurbo(this, 51, 4, textureX, textureY); // Box 1
		surgeonkitModel[2] = new ModelRendererTurbo(this, 0, 13, textureX, textureY); // Box 2
		surgeonkitModel[3] = new ModelRendererTurbo(this, 0, 21, textureX, textureY); // Box 3
		surgeonkitModel[4] = new ModelRendererTurbo(this, 93, 16, textureX, textureY); // Box 4
		surgeonkitModel[5] = new ModelRendererTurbo(this, -1, 141, textureX, textureY); // Box 6
		surgeonkitModel[6] = new ModelRendererTurbo(this, -58, 58, textureX, textureY); // Box 7
		surgeonkitModel[7] = new ModelRendererTurbo(this, 64, 11, textureX, textureY); // Box 8
		surgeonkitModel[8] = new ModelRendererTurbo(this, 70, 26, textureX, textureY); // Box 10
		surgeonkitModel[9] = new ModelRendererTurbo(this, 78, 6, textureX, textureY); // Box 11
		surgeonkitModel[10] = new ModelRendererTurbo(this, 0, 1, textureX, textureY); // Box 12
		surgeonkitModel[11] = new ModelRendererTurbo(this, 0, 7, textureX, textureY); // Box 13
		surgeonkitModel[12] = new ModelRendererTurbo(this, 1, 43, textureX, textureY); // Box 15
		surgeonkitModel[13] = new ModelRendererTurbo(this, 138, 6, textureX, textureY); // Box 14

		surgeonkitModel[0].addShapeBox(-128F, 0F, -57F, 256, 1, 128, 0F, -118F, 0F, -60F, -118F, 0F, -60F, -118F, 0F, -60F, -118F, 0F, -60F, -118F, 0F, -60F, -118F, 0F, -60F, -118F, 0F, -60F, -118F, 0F, -60F); // Box 0
		surgeonkitModel[0].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[1].addBox(-12F, 0F, -7F, 1, 6, 10, 0F); // Box 1
		surgeonkitModel[1].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[2].addBox(-12F, 0F, -8F, 24, 6, 1, 0F); // Box 2
		surgeonkitModel[2].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[3].addBox(-12F, 0F, 3F, 24, 6, 1, 0F); // Box 3
		surgeonkitModel[3].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[4].addBox(11F, 0F, -7F, 1, 6, 10, 0F); // Box 4
		surgeonkitModel[4].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[5].addShapeBox(-130F, 1.5F, -66F, 256, 0, 128, 0F, -120F, 0F, -59F, -120F, 0F, -59F, -120F, 0F, -59F, -120F, 0F, -59F, -120F, 0F, -59F, -120F, 0F, -59F, -120F, 0F, -59F, -120F, 0F, -59F); // Box 6
		surgeonkitModel[5].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[6].addShapeBox(-23F, 1.5F, -34F, 64, 0, 64, 0F, -30F, 0F, -27F, -30F, 0F, -27F, -30F, 0F, -27F, -30F, 0F, -27F, -30F, 0F, -27F, -30F, 0F, -27F, -30F, 0F, -27F, -30F, 0F, -27F); // Box 7
		surgeonkitModel[6].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[7].addBox(6F, 1F, -7F, 1, 5, 10, 0F); // Box 8
		surgeonkitModel[7].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[8].addShapeBox(-12F, 3F, -20.5F, 1, 4, 10, 0F, 0F, -7F, -3F, 0F, -7F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 6F, -6F, 0F, 6F, -6F, 0F, -1F, 3F, 0F, -1F, 3F); // Box 10
		surgeonkitModel[8].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[9].addShapeBox(11F, 3F, -20.5F, 1, 4, 10, 0F, 0F, -7F, -3F, 0F, -7F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 6F, -6F, 0F, 6F, -6F, 0F, -1F, 3F, 0F, -1F, 3F); // Box 11
		surgeonkitModel[9].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[10].addShapeBox(-11F, 3F, -11.5F, 22, 4, 1, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, -1F, 3F, 0F, -1F, 3F); // Box 12
		surgeonkitModel[10].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[11].addShapeBox(-11F, 9F, -17.5F, 22, 4, 1, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, -1F, 3F, 0F, -1F, 3F); // Box 13
		surgeonkitModel[11].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[12].addShapeBox(-12F, 2F, -20.5F, 24, 1, 10, 0F, 0F, -7F, -2F, 0F, -7F, -2F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 7F, -3F, 0F, 7F, -3F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 15
		surgeonkitModel[12].setRotationPoint(0F, 0F, 0F);

		surgeonkitModel[13].addShapeBox(-128F, 0F, -66F, 256, 1, 128, 0F, -117F, 0F, -59F, -117F, 0F, -59F, -117F, 0F, -59F, -117F, 0F, -59F, -117F, 0F, -59F, -117F, 0F, -59F, -117F, 0F, -59F, -117F, 0F, -59F); // Box 14
		surgeonkitModel[13].setRotationPoint(0F, 0F, 0F);


	}

	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
	{
		for(int i = 0; i < 14; i++)
		{
			surgeonkitModel[i].render(f5);
		}
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5)
	{
	}

	public ModelRendererTurbo surgeonkitModel[];
}