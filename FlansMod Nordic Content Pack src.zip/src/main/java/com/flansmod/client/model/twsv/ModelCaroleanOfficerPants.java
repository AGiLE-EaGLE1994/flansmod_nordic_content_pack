//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: CaroleanOfficerPants
// Model Creator: 
// Created on: 10.03.2020 - 11:17:29
// Last changed on: 10.03.2020 - 11:17:29

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.ModelCustomArmour;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelCaroleanOfficerPants extends ModelCustomArmour //Same as Filename
{
	int textureX = 64;
	int textureY = 32;

	public ModelCaroleanOfficerPants() //Same as Filename
	{
		leftLegModel = new ModelRendererTurbo[3];
		leftLegModel[0] = new ModelRendererTurbo(this, 38, 23, textureX, textureY); // Box 15
		leftLegModel[1] = new ModelRendererTurbo(this, 0, 20, textureX, textureY); // Box 6
		leftLegModel[2] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 14

		leftLegModel[0].addShapeBox(0.25F, -1.1F, -2.5F, 3, 4, 5, 0F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, -3.5F, 1.5F, 0.25F, 0.75F, -2.75F, 0.25F, 0.75F, -2.75F, 0.25F, -3.5F, 1.5F, 0.25F); // Box 15
		leftLegModel[0].setRotationPoint(0F, 0F, 0F);

		leftLegModel[1].addShapeBox(-1.85F, 0.5F, -2F, 4, 8, 4, 0F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F); // Box 6
		leftLegModel[1].setRotationPoint(0F, 0F, 0F);

		leftLegModel[2].addShapeBox(-4.15F, -2F, -2.55F, 6, 6, 0, 0F, -2F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, -2F, -1F, 0F, -2F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, -2F, -2F, 0F); // Box 14
		leftLegModel[2].setRotationPoint(0F, 0F, 0F);


		rightLegModel = new ModelRendererTurbo[7];
		rightLegModel[0] = new ModelRendererTurbo(this, 42, 15, textureX, textureY); // Box 4
		rightLegModel[1] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 7
		rightLegModel[2] = new ModelRendererTurbo(this, 17, 0, textureX, textureY); // Box 9
		rightLegModel[3] = new ModelRendererTurbo(this, 38, 23, textureX, textureY); // Box 12
		rightLegModel[4] = new ModelRendererTurbo(this, 17, 0, textureX, textureY); // Box 13
		rightLegModel[5] = new ModelRendererTurbo(this, 41, 15, textureX, textureY); // Box 14
		rightLegModel[6] = new ModelRendererTurbo(this, 0, 20, textureX, textureY); // Box 7

		rightLegModel[0].addShapeBox(-4.15F, -1F, -2.5F, 6, 3, 5, 0F, -1F, 0F, 0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, -1F, 0F, -0.25F, -0.75F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.25F, 2F, 0F); // Box 4
		rightLegModel[0].setRotationPoint(0F, 0F, 0F);

		rightLegModel[1].addShapeBox(-4.15F, -2F, 2.35F, 6, 6, 0, 0F, -2F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, -2F, -1F, 0F, -2F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, -2F, -2F, 0F); // Box 7
		rightLegModel[1].setRotationPoint(0F, 0F, -5F);

		rightLegModel[2].addShapeBox(-3.15F, 0F, -2.5F, 5, 6, 5, 0F, 0.5F, -4F, 0F, 0F, -1.99F, 0F, 0F, -1.99F, 0F, 0.5F, -4F, 0F, 1F, 2F, 0F, 0F, -4F, 0F, 0F, -4F, 0F, 1F, 2F, 0F); // Box 9
		rightLegModel[2].setRotationPoint(0F, 0F, 0F);

		rightLegModel[3].addShapeBox(-3.5F, -1.1F, -2.5F, 3, 4, 5, 0F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0.75F, -2.75F, 0.25F, -3.5F, 1.5F, 0.25F, -3.5F, 1.5F, 0.25F, 0.75F, -2.75F, 0.25F); // Box 12
		rightLegModel[3].setRotationPoint(0F, 0F, 0F);

		rightLegModel[4].addShapeBox(1.85F, 0F, -2.5F, 5, 6, 5, 0F, 0F, -1.99F, 0F, 0.5F, -4F, 0F, 0.5F, -4F, 0F, 0F, -1.99F, 0F, 0F, -4F, 0F, 1F, 2F, 0F, 1F, 2F, 0F, 0F, -4F, 0F); // Box 13
		rightLegModel[4].setRotationPoint(0F, 0F, 0F);

		rightLegModel[5].addShapeBox(1.85F, -1F, -2.5F, 6, 3, 5, 0F, 0F, 0F, -0.25F, -1F, 0F, -0.25F, -1F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, 0F, -0.75F, 2F, 0F, -0.75F, 2F, 0F, 0F, 0F, 0F); // Box 14
		rightLegModel[5].setRotationPoint(0F, 0F, 0F);

		rightLegModel[6].addShapeBox(-2.15F, 0.5F, -2F, 4, 8, 4, 0F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F, 0.25F); // Box 7
		rightLegModel[6].setRotationPoint(0F, 0F, 0F);


	}
}