//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: DanishGeneralTunic
// Model Creator: 
// Created on: 10.03.2020 - 11:17:29
// Last changed on: 10.03.2020 - 11:17:29

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.ModelCustomArmour;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelDanishGeneralTunic extends ModelCustomArmour //Same as Filename
{
	int textureX = 64;
	int textureY = 32;

	public ModelDanishGeneralTunic() //Same as Filename
	{
		bodyModel = new ModelRendererTurbo[2];
		bodyModel[0] = new ModelRendererTurbo(this, 16, 1, textureX, textureY); // Box 4
		bodyModel[1] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 6

		bodyModel[0].addShapeBox(-4.5F, -0.2F, -2.5F, 9, 12, 5, 0F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.75F, 0F, -0.5F, -0.75F, 0F, -0.5F, -0.75F, 0F, -0.5F, -0.75F, 0F, -0.5F); // Box 4
		bodyModel[0].setRotationPoint(0F, 0F, 0F);

		bodyModel[1].addShapeBox(-4F, 0F, -3F, 2, 12, 6, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, -8F, 0F, -0.5F, 6F, -2F, -0.5F, 6F, -2F, -0.5F, -8F, 0F, -0.5F); // Box 6
		bodyModel[1].setRotationPoint(0F, 0F, 0F);


		leftArmModel = new ModelRendererTurbo[1];
		leftArmModel[0] = new ModelRendererTurbo(this, 2, 18, textureX, textureY); // Box 9

		leftArmModel[0].addBox(-1F, -2F, -2F, 4, 7, 4, 0F); // Box 9
		leftArmModel[0].setRotationPoint(0F, 0F, 0F);


		rightArmModel = new ModelRendererTurbo[1];
		rightArmModel[0] = new ModelRendererTurbo(this, 19, 18, textureX, textureY); // Box 8

		rightArmModel[0].addBox(-3F, -2F, -2F, 4, 7, 4, 0F); // Box 8
		rightArmModel[0].setRotationPoint(0F, 0F, 0F);


	}
}