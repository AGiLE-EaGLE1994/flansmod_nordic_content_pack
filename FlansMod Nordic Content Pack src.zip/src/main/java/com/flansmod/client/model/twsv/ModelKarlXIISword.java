//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: KarlXIISword
// Model Creator: 
// Created on: 10.03.2020 - 17:41:26
// Last changed on: 10.03.2020 - 17:41:26

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelKarlXIISword extends ModelGun //Same as Filename
{
	int textureX = 64;
	int textureY = 32;

	public ModelKarlXIISword() //Same as Filename
	{
		gunModel = new ModelRendererTurbo[12];

		initgunModel_1();

		translateAll(0F, 0F, 0F);


		flipAll();
	}

	private void initgunModel_1()
	{
		gunModel[0] = new ModelRendererTurbo(this, 34, 0, textureX, textureY); // Import 
		gunModel[1] = new ModelRendererTurbo(this, 28, 0, textureX, textureY); // Import 
		gunModel[2] = new ModelRendererTurbo(this, 0, 1, textureX, textureY); // Import 
		gunModel[3] = new ModelRendererTurbo(this, 22, 10, textureX, textureY); // Import 
		gunModel[4] = new ModelRendererTurbo(this, 6, 12, textureX, textureY); // Box 4
		gunModel[5] = new ModelRendererTurbo(this, 1, 10, textureX, textureY); // Box 5
		gunModel[6] = new ModelRendererTurbo(this, 1, 15, textureX, textureY); // Box 6
		gunModel[7] = new ModelRendererTurbo(this, 25, 17, textureX, textureY); // Box 7
		gunModel[8] = new ModelRendererTurbo(this, 32, 17, textureX, textureY); // Box 8
		gunModel[9] = new ModelRendererTurbo(this, 0, 17, textureX, textureY); // Box 9
		gunModel[10] = new ModelRendererTurbo(this, 32, 17, textureX, textureY); // Box 10
		gunModel[11] = new ModelRendererTurbo(this, 32, 2, textureX, textureY); // Box 11

		gunModel[0].addShapeBox(-1F, -12F, 0F, 2, 10, 0, 0F,-0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Import 
		gunModel[0].setRotationPoint(0F, 0F, 0F);

		gunModel[1].addShapeBox(-1F, -26F, 0F, 2, 14, 0, 0F,-0.99F, 0F, 0F, -0.99F, 0F, 0F, -0.99F, 0F, 0F, -0.99F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F); // Import 
		gunModel[1].setRotationPoint(0F, 0F, 0F);

		gunModel[2].addShapeBox(-6F, -5F, -1F, 12, 6, 2, 0F,-4F, -2.25F, 0F, -4F, -2.25F, 0F, -4F, -2.25F, 0F, -4F, -2.25F, 0F, -4F, -2.25F, 0F, -4F, -2.25F, 0F, -4F, -2.25F, 0F, -4F, -2.25F, 0F); // Import 
		gunModel[2].setRotationPoint(0F, 0F, 0F);

		gunModel[3].addTrapezoid(-0.5F, 2.5F, -0.5F, 1, 3, 1, 0F, 0.35F, ModelRendererTurbo.MR_TOP); // Import 
		gunModel[3].setRotationPoint(0F, 0F, 0F);

		gunModel[4].addBox(-2.5F, -1.5F, -1.5F, 6, 1, 3, 0F); // Box 4
		gunModel[4].setRotationPoint(0F, 0F, 0F);

		gunModel[5].addShapeBox(1.5F, -0.5F, -1F, 1, 2, 2, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F); // Box 5
		gunModel[5].setRotationPoint(0F, 0F, 0F);

		gunModel[6].addTrapezoid(-0.5F, -0.5F, -0.5F, 1, 3, 1, 0F, 0.35F, ModelRendererTurbo.MR_BOTTOM); // Box 6
		gunModel[6].setRotationPoint(0F, 0F, 0F);

		gunModel[7].addBox(2.5F, 1.5F, -1F, 1, 2, 2, 0F); // Box 7
		gunModel[7].setRotationPoint(0F, 0F, 0F);

		gunModel[8].addShapeBox(1.5F, 3.5F, -1F, 1, 2, 2, 0F,-1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, 1F, 0F, -0.5F); // Box 8
		gunModel[8].setRotationPoint(0F, 0F, 0F);

		gunModel[9].addShapeBox(-4F, 4.5F, -4F, 8, 7, 8, 0F,-2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F); // Box 9
		gunModel[9].setRotationPoint(0F, 0F, 0F);

		gunModel[10].addShapeBox(-4F, 2.5F, -4F, 8, 7, 8, 0F,-3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -3F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F); // Box 10
		gunModel[10].setRotationPoint(0F, 0F, 0F);

		gunModel[11].addShapeBox(-4F, 3.5F, -4F, 8, 7, 8, 0F,-2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F, -2.5F, -3F, -2.5F); // Box 11
		gunModel[11].setRotationPoint(0F, 0F, 0F);
	}
}