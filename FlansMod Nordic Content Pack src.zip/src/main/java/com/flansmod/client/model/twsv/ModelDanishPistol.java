//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: DanishPistol
// Model Creator: 
// Created on: 11.03.2020 - 11:22:09
// Last changed on: 11.03.2020 - 11:22:09

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelDanishPistol extends ModelGun //Same as Filename
{
	int textureX = 64;
	int textureY = 64;

	public ModelDanishPistol() //Same as Filename
	{
		gunModel = new ModelRendererTurbo[12];
		gunModel[0] = new ModelRendererTurbo(this, 30, 19, textureX, textureY); // Import Box3
		gunModel[1] = new ModelRendererTurbo(this, 13, 21, textureX, textureY); // Import Box21
		gunModel[2] = new ModelRendererTurbo(this, 0, 21, textureX, textureY); // Import Box23
		gunModel[3] = new ModelRendererTurbo(this, 0, 11, textureX, textureY); // Box 59
		gunModel[4] = new ModelRendererTurbo(this, 1, 25, textureX, textureY); // Box 60
		gunModel[5] = new ModelRendererTurbo(this, 1, 25, textureX, textureY); // Box 62
		gunModel[6] = new ModelRendererTurbo(this, 0, 2, textureX, textureY); // Box 63
		gunModel[7] = new ModelRendererTurbo(this, 1, 25, textureX, textureY); // Box 67
		gunModel[8] = new ModelRendererTurbo(this, 1, 25, textureX, textureY); // Box 68
		gunModel[9] = new ModelRendererTurbo(this, 13, 21, textureX, textureY); // Box 23
		gunModel[10] = new ModelRendererTurbo(this, 13, 21, textureX, textureY); // Box 24
		gunModel[11] = new ModelRendererTurbo(this, 0, 11, textureX, textureY); // Box 27

		gunModel[0].addShapeBox(-1.25F, -4.5F, -2.4F, 7, 3, 3, 0F, 0F, -1.25F, -0.75F, 0F, -1.25F, -0.75F, 0F, -1.25F, -0.75F, 0F, -1.25F, -0.75F, 0F, -0.5F, -0.75F, 0F, -0.5F, -0.75F, 0F, -0.5F, -0.75F, 0F, -0.5F, -0.75F); // Import Box3
		gunModel[0].setRotationPoint(0F, 0F, 0F);

		gunModel[1].addShapeBox(2F, -2F, -1.4F, 1, 2, 1, 0F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F); // Import Box21
		gunModel[1].setRotationPoint(0F, 0F, 0F);

		gunModel[2].addShapeBox(-1F, -0.75F, -2.4F, 5, 1, 3, 0F, 0.25F, 0F, -1.25F, -1.25F, 0F, -1.25F, -1.25F, 0F, -1.25F, 0.25F, 0F, -1.25F, -0.25F, -0.5F, -1.25F, -1.5F, -0.5F, -1.25F, -1.5F, -0.5F, -1.25F, -0.25F, -0.5F, -1.25F); // Import Box23
		gunModel[2].setRotationPoint(0F, 0F, 0F);

		gunModel[3].addShapeBox(-5F, -5.7F, -1F, 15, 9, 1, 0F, -5F, -2.5F, -0.75F, -5F, -2.5F, -0.75F, -5F, -2.5F, 0F, -5F, -2.5F, 0F, -4F, -5.5F, -0.75F, -4F, -5.5F, -0.75F, -4F, -5.5F, 0F, -4F, -5.5F, 0F); // Box 59
		gunModel[3].setRotationPoint(0F, 0F, 0F);

		gunModel[4].addShapeBox(0F, -3.25F, 0F, 2, 1, 1, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, -0.5F, 0F, -0.5F, -0.5F, 0F); // Box 60
		gunModel[4].setRotationPoint(0F, 0F, 0F);

		gunModel[5].addShapeBox(3F, -3.25F, 0F, 2, 1, 1, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, -1F, -0.75F, 0F, 0F, -0.75F, 0F); // Box 62
		gunModel[5].setRotationPoint(0F, 0F, 0F);

		gunModel[6].addShapeBox(3F, -5.25F, 0F, 1, 2, 1, 0F, -0.75F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, -0.75F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 63
		gunModel[6].setRotationPoint(0F, 0F, 0F);

		gunModel[7].addShapeBox(3F, -2.75F, 0F, 2, 1, 1, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, 0F, -0.85F, 0F, 0F, -0.85F, 0F, 0F, -0.85F, 0F, -0.5F, -0.85F, 0F); // Box 67
		gunModel[7].setRotationPoint(0F, 0F, 0F);

		gunModel[8].addShapeBox(3F, -2.6F, 0F, 2, 1, 1, 0F, 0F, -0.25F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -0.25F, 0F, 0F, -0.6F, 0F, 0F, -0.85F, 0F, 0F, -0.85F, 0F, -0.5F, -0.6F, 0F); // Box 68
		gunModel[8].setRotationPoint(0F, 0F, 0F);

		gunModel[9].addShapeBox(-1.5F, -2F, -1.4F, 1, 2, 1, 0F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F); // Box 23
		gunModel[9].setRotationPoint(0F, 0F, 0F);

		gunModel[10].addShapeBox(0.5F, -1.9F, -1.4F, 1, 2, 1, 0F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, -1F, -0.75F, -0.75F, -1F, -0.75F, -0.75F, -1F, -0.75F, -0.75F, -1F, -0.75F); // Box 24
		gunModel[10].setRotationPoint(0F, 0F, 0F);
		gunModel[10].rotateAngleY = -0.01745329F;
		gunModel[10].rotateAngleZ = 0.13962634F;

		gunModel[11].addShapeBox(-5F, -5.7F, -2.5F, 15, 9, 1, 0F, -5F, -2.5F, -0.75F, -5F, -2.5F, -0.75F, -5F, -2.5F, 0F, -5F, -2.5F, 0F, -4F, -5.5F, -0.75F, -4F, -5.5F, -0.75F, -4F, -5.5F, 0F, -4F, -5.5F, 0F); // Box 27
		gunModel[11].setRotationPoint(0F, 0F, 0F);


		defaultBarrelModel = new ModelRendererTurbo[3];
		defaultBarrelModel[0] = new ModelRendererTurbo(this, 2, 3, textureX, textureY); // Box 53
		defaultBarrelModel[1] = new ModelRendererTurbo(this, 1, 28, textureX, textureY); // Box 55
		defaultBarrelModel[2] = new ModelRendererTurbo(this, 42, 14, textureX, textureY); // Box 58

		defaultBarrelModel[0].addShapeBox(5.75F, -3.75F, -2.4F, 26, 4, 3, 0F, 0F, -0.5F, -0.75F, -21.75F, -0.5F, -1F, -21.75F, -0.5F, -1F, 0F, -0.5F, -0.75F, 0F, -2.3F, -0.75F, -22F, -2.3F, -1F, -22F, -2.3F, -1F, 0F, -2.3F, -0.75F); // Box 53
		defaultBarrelModel[0].setRotationPoint(0F, 0F, 0F);

		defaultBarrelModel[1].addShapeBox(2F, -3.64F, -1.4F, 29, 1, 1, 0F, 0F, -0.1F, -0.1F, -16F, -0.1F, -0.1F, -16F, -0.1F, -0.1F, 0F, -0.1F, -0.1F, 0F, -0.1F, -0.1F, -16F, -0.1F, -0.1F, -16F, -0.1F, -0.1F, 0F, -0.1F, -0.1F); // Box 55
		defaultBarrelModel[1].setRotationPoint(0F, 0F, 0F);

		defaultBarrelModel[2].addShapeBox(10F, -3.25F, -1.9F, 4, 2, 2, 0F, 0F, 0F, -0.5F, 0.5F, 0F, -0.5F, 0.5F, 0F, -0.5F, 0F, 0F, -0.5F, 0.25F, -0.8F, -0.5F, 0.5F, -1.1F, -0.5F, 0.5F, -1.1F, -0.5F, 0.25F, -0.8F, -0.5F); // Box 58
		defaultBarrelModel[2].setRotationPoint(0F, 0F, 0F);


		defaultStockModel = new ModelRendererTurbo[7];
		defaultStockModel[0] = new ModelRendererTurbo(this, 1, 31, textureX, textureY); // Box 52
		defaultStockModel[1] = new ModelRendererTurbo(this, 33, 12, textureX, textureY); // Box 31
		defaultStockModel[2] = new ModelRendererTurbo(this, 23, 24, textureX, textureY); // Box 22
		defaultStockModel[3] = new ModelRendererTurbo(this, 18, 24, textureX, textureY); // Box 23
		defaultStockModel[4] = new ModelRendererTurbo(this, 23, 24, textureX, textureY); // Box 24
		defaultStockModel[5] = new ModelRendererTurbo(this, 18, 24, textureX, textureY); // Box 25
		defaultStockModel[6] = new ModelRendererTurbo(this, 14, 31, textureX, textureY); // Box 26

		defaultStockModel[0].addShapeBox(-5.25F, -3.5F, -1.9F, 4, 2, 2, 0F, 0F, -1.5F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -1.5F, -0.25F, -1F, 0.75F, -0.25F, 0F, -0.5F, -0.25F, 0F, -0.5F, -0.25F, -1F, 0.75F, -0.25F); // Box 52
		defaultStockModel[0].setRotationPoint(0F, 0F, 0F);

		defaultStockModel[1].addShapeBox(-7.5F, -1.85F, -2.4F, 1, 3, 3, 0F, -1F, -0.75F, -1F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, -1F, -0.75F, -1F, -2.25F, -1F, -1F, 1.75F, -1F, -0.5F, 1.75F, -1F, -0.5F, -2.25F, -1F, -1F); // Box 31
		defaultStockModel[1].setRotationPoint(0F, 0F, 0F);

		defaultStockModel[2].addShapeBox(-4.25F, -2.5F, -0.65F, 1, 2, 1, 0F, 2.2F, -0.65F, -0.5F, -1.75F, -0.75F, -0.5F, -1.55F, -0.9F, -0.25F, 2.25F, -0.65F, -0.25F, 0.5F, 0.65F, -0.55F, -0.9F, -0.5F, -0.5F, -1.05F, -0.65F, -0.25F, 0.5F, 0.65F, -0.25F); // Box 22
		defaultStockModel[2].setRotationPoint(0F, 0F, 0F);

		defaultStockModel[3].addShapeBox(-4.15F, -2F, -0.65F, 1, 1, 1, 0F, 1.05F, -0.1F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.5F, 0.65F, -0.4F, -0.25F, 0F, 0.03F, -0.5F, 0F, -0.9F, -0.25F, 0F, -0.95F, -0.5F, 0.15F, -0.15F, -0.25F); // Box 23
		defaultStockModel[3].setRotationPoint(0F, 0F, 0F);

		defaultStockModel[4].addShapeBox(-4.25F, -2.5F, -2.15F, 1, 2, 1, 0F, 2.25F, -0.65F, -0.25F, -1.55F, -0.9F, -0.25F, -1.75F, -0.75F, -0.5F, 2.2F, -0.65F, -0.5F, 0.5F, 0.65F, -0.25F, -1.05F, -0.65F, -0.25F, -0.9F, -0.5F, -0.5F, 0.5F, 0.65F, -0.55F); // Box 24
		defaultStockModel[4].setRotationPoint(0F, 0F, 0F);

		defaultStockModel[5].addShapeBox(-4.15F, -2F, -2.15F, 1, 1, 1, 0F, 0.65F, -0.4F, -0.25F, 0F, 0F, -0.5F, 0F, 0F, -0.25F, 1.05F, -0.1F, -0.25F, 0.15F, -0.15F, -0.25F, 0F, -0.95F, -0.5F, 0F, -0.9F, -0.25F, 0F, 0.03F, -0.5F); // Box 25
		defaultStockModel[5].setRotationPoint(0F, 0F, 0F);

		defaultStockModel[6].addShapeBox(-7F, -2F, -1.9F, 2, 2, 2, 0F, -0.5F, -0.15F, 0F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.5F, -0.15F, 0F, -2.25F, 0.15F, 0F, 1F, -0.85F, -0.25F, 1F, -0.85F, -0.25F, -2.25F, 0.15F, 0F); // Box 26
		defaultStockModel[6].setRotationPoint(0F, 0F, 0F);


		ammoModel = new ModelRendererTurbo[1];
		ammoModel[0] = new ModelRendererTurbo(this, 39, 11, textureX, textureY); // Box 57

		ammoModel[0].addShapeBox(8.75F, -2.75F, -1.4F, 6, 1, 1, 0F, 0F, -0.4F, -0.4F, 0F, -0.4F, -0.4F, 0F, -0.4F, -0.4F, 0F, -0.4F, -0.4F, 0F, -0.4F, -0.4F, 0F, -0.4F, -0.4F, 0F, -0.4F, -0.4F, 0F, -0.4F, -0.4F); // Box 57
		ammoModel[0].setRotationPoint(0F, 0F, 0F);


		leverActionModel = new ModelRendererTurbo[4];
		leverActionModel[0] = new ModelRendererTurbo(this, 0, 3, textureX, textureY); // Box 61
		leverActionModel[1] = new ModelRendererTurbo(this, 0, 3, textureX, textureY); // Box 64
		leverActionModel[2] = new ModelRendererTurbo(this, 0, 3, textureX, textureY); // Box 65
		leverActionModel[3] = new ModelRendererTurbo(this, 0, 3, textureX, textureY); // Box 66

		leverActionModel[0].addShapeBox(1F, -4.25F, 0F, 1, 1, 1, 0F, -0.5F, 0F, -0.25F, -0.25F, -0.25F, -0.25F, -0.25F, -0.25F, -0.25F, -0.5F, 0F, -0.25F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 61
		leverActionModel[0].setRotationPoint(0F, 0F, 0F);

		leverActionModel[1].addShapeBox(0.5F, -4.75F, 0F, 1, 1, 1, 0F, 0F, 0F, -0.25F, 0F, -0.5F, -0.25F, 0F, -0.5F, -0.25F, 0F, 0F, -0.25F, 0F, -0.5F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, 0F, -0.5F, -0.25F); // Box 64
		leverActionModel[1].setRotationPoint(0F, 0F, 0F);

		leverActionModel[2].addShapeBox(0.5F, -5.75F, 0F, 1, 1, 1, 0F, 0F, -0.99F, -0.25F, -0.5F, -0.75F, -0.25F, -0.5F, -0.75F, -0.25F, 0F, -0.99F, -0.25F, 0F, 0F, -0.25F, -0.5F, 0.25F, -0.25F, -0.5F, 0.25F, -0.25F, 0F, 0F, -0.25F); // Box 65
		leverActionModel[2].setRotationPoint(0F, 0F, 0F);

		leverActionModel[3].addShapeBox(0.5F, -5.75F, 0F, 1, 1, 1, 0F, 0F, -0.5F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, -0.5F, -0.25F, 0F, 0F, -0.25F, 0.25F, -0.5F, -0.25F, 0.25F, -0.5F, -0.25F, 0F, 0F, -0.25F); // Box 66
		leverActionModel[3].setRotationPoint(0F, 0F, 0F);



		gripAttachPoint = new Vector3f(-18 /16F, 15F /16F, 0F /16F);


		itemFrameOffset = new Vector3f(0 /16F, -6F /16F, -9F /16F);


		gunSlideDistance = 4F;


		animationType = EnumAnimationType.END_LOADED;


		tiltGunTime = 40F;


		unloadClipTime = 40F;


		loadClipTime = 40F;


		untiltGunTime = 40F;


		endLoadedAmmoDistance = 40F;


		pumpTime = 0;


		pumpHandleDistance = 0F;


		minigunBarrelOrigin = new Vector3f(0 /16F, -12F /16F, 0F /16F);


		barrelBreakPoint = new Vector3f(0 /16F, 6F /16F, 0F /16F);


		spinPoint = new Vector3f(0 /16F, -30F /16F, 0F /16F);


		translateAll(0F, 0F, 0F);


		flipAll();
	}
}