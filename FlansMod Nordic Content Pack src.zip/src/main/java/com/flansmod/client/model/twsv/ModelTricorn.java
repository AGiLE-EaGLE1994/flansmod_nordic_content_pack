//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: Tricorn
// Model Creator: 
// Created on: 10.03.2020 - 11:17:29
// Last changed on: 10.03.2020 - 11:17:29

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.ModelCustomArmour;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelTricorn extends ModelCustomArmour //Same as Filename
{
	int textureX = 64;
	int textureY = 32;

	public ModelTricorn() //Same as Filename
	{
		headModel = new ModelRendererTurbo[13];
		headModel[0] = new ModelRendererTurbo(this, 0, 15, textureX, textureY); // Box 13
		headModel[1] = new ModelRendererTurbo(this, 31, 19, textureX, textureY); // Box 2
		headModel[2] = new ModelRendererTurbo(this, 31, 19, textureX, textureY); // Box 9
		headModel[3] = new ModelRendererTurbo(this, 31, 19, textureX, textureY); // Box 11
		headModel[4] = new ModelRendererTurbo(this, 31, 19, textureX, textureY); // Box 9
		headModel[5] = new ModelRendererTurbo(this, 0, 13, textureX, textureY); // Box 11
		headModel[6] = new ModelRendererTurbo(this, -1, 19, textureX, textureY); // Box 14
		headModel[7] = new ModelRendererTurbo(this, 3, 20, textureX, textureY); // Box 15
		headModel[8] = new ModelRendererTurbo(this, 0, 13, textureX, textureY); // Box 16
		headModel[9] = new ModelRendererTurbo(this, 4, 20, textureX, textureY); // Box 11
		headModel[10] = new ModelRendererTurbo(this, -1, 20, textureX, textureY); // Box 12
		headModel[11] = new ModelRendererTurbo(this, 32, 19, textureX, textureY); // Box 13
		headModel[12] = new ModelRendererTurbo(this, 0, 30, textureX, textureY); // Box 14

		headModel[0].addTrapezoid(-2.5F, -13.75F, -2F, 5, 6, 5, 0F, -1.50F, ModelRendererTurbo.MR_TOP); // Box 13
		headModel[0].setRotationPoint(0F, 0F, 0F);

		headModel[1].addShapeBox(-4.5F, -7.75F, -2.5F, 9, 1, 8, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -4.49F, 0F, -1F, -4.49F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, -4.49F, 0F, 0F, -4.49F, 0F, 0F); // Box 2
		headModel[1].setRotationPoint(0F, 0F, 0F);

		headModel[2].addShapeBox(-9F, -7.75F, -2.5F, 9, 1, 8, 0F, -0.5F, 2.5F, -7.5F, -3.5F, 0F, 0F, 0F, 0F, -1F, -0.75F, 2.5F, 0F, 0F, -3F, -7.5F, -4.5F, 0F, 1F, 0F, 0F, 0F, -0.5F, -3F, 0.5F); // Box 9
		headModel[2].setRotationPoint(0F, 0F, 0F);

		headModel[3].addShapeBox(0F, -7.75F, -2.5F, 9, 1, 8, 0F, -3.5F, 0F, 0F, -0.5F, 2.5F, -7.5F, -0.75F, 2.5F, 0F, 0F, 0F, -1F, -4.5F, 0F, 1F, 0F, -3F, -7.5F, -0.5F, -3F, 0.5F, 0F, 0F, 0F); // Box 11
		headModel[3].setRotationPoint(0F, 0F, 0F);

		headModel[4].addShapeBox(-4.5F, -7.75F, -10.5F, 9, 1, 8, 0F, -4F, 2.5F, 0F, -4F, 2.5F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -4F, -3F, 0F, -4F, -3F, 0F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 9
		headModel[4].setRotationPoint(0F, 0F, 0F);

		headModel[5].addShapeBox(-4.5F, -11.75F, -10.5F, 1, 5, 8, 0F, -3F, 0F, 0F, 2.5F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, -1F, -4F, -3F, 0F, 3F, -3.5F, 0F, 0.25F, 0F, 0F, 0F, 0F, -1F); // Box 11
		headModel[5].setRotationPoint(0F, 0F, 0F);

		headModel[6].addShapeBox(-9F, -11.75F, 4.5F, 9, 5, 1, 0F, -0.75F, 0F, -1.25F, 0F, 0F, 0F, 0F, 0F, -0.5F, -1F, 0F, 1F, -0.75F, -3.5F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -3F, 0.5F); // Box 14
		headModel[6].setRotationPoint(0F, 0F, 0F);

		headModel[7].addShapeBox(-10.5F, -11.75F, -3.5F, 6, 5, 1, 0F, -1.5F, 0F, -7.5F, 0F, 0F, 0F, 0F, 0F, 0F, -1.75F, 0F, 7F, -1.5F, -3F, -8.5F, 0F, 0F, 0F, 1F, -1F, 0F, -2F, -3.5F, 7.5F); // Box 15
		headModel[7].setRotationPoint(0F, 0F, 0F);

		headModel[8].addShapeBox(3.5F, -11.75F, -10.5F, 1, 5, 8, 0F, 2.5F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, -1F, -1F, 0F, 0F, 3F, -3.5F, 0F, -4F, -3F, 0F, 0F, 0F, -1F, 0.25F, 0F, 0F); // Box 16
		headModel[8].setRotationPoint(0F, 0F, 0F);

		headModel[9].addShapeBox(4.5F, -11.75F, -3.5F, 6, 5, 1, 0F, 0F, 0F, 0F, -1.5F, 0F, -7.5F, -1.75F, 0F, 7F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, -3F, -8.5F, -2F, -3.5F, 7.5F, 1F, -1F, 0F); // Box 11
		headModel[9].setRotationPoint(0F, 0F, 0F);

		headModel[10].addShapeBox(0F, -11.75F, 4.5F, 9, 5, 1, 0F, 0F, 0F, 0F, -0.75F, 0F, -1.25F, -1F, 0F, 1F, 0F, 0F, -0.5F, 0F, 0F, 0F, -0.75F, -3.5F, -1F, -0.5F, -3F, 0.5F, 0F, 0F, 0F); // Box 12
		headModel[10].setRotationPoint(0F, 0F, 0F);

		headModel[11].addShapeBox(-4F, -8F, -4F, 8, 3, 8, 0F, -0.5F, -1F, -0.5F, -0.5F, -1F, -0.5F, -0.5F, -0.25F, -0.5F, -0.5F, -0.25F, -0.5F, -0.5F, 0F, -0.5F, -0.5F, 0F, -0.5F, -0.5F, 0F, -0.5F, -0.5F, 0F, -0.5F); // Box 13
		headModel[11].setRotationPoint(0F, 0F, 0F);

		headModel[12].addBox(-3F, -7F, -3.6F, 6, 2, 0, 0F); // Box 14
		headModel[12].setRotationPoint(0F, 0F, 0F);


	}
}