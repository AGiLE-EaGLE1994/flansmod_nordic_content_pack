//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: HardTack
// Model Creator:
// Created on:23.04.2020 - 21:20:08
// Last changed on: 23.04.2020 - 21:20:08

package com.flansmod.client.model.twsv;

import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.Entity;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelHardTack extends ModelBase
{
	int textureX = 1024;
	int textureY = 1024;

	public ModelHardTack()
	{
		hardtackModel = new ModelRendererTurbo[5];
		hardtackModel[0] = new ModelRendererTurbo(this, -1, 2, textureX, textureY); // Box 0
		hardtackModel[1] = new ModelRendererTurbo(this, 54, 28, textureX, textureY); // Box 1
		hardtackModel[2] = new ModelRendererTurbo(this, 54, 28, textureX, textureY); // Box 2
		hardtackModel[3] = new ModelRendererTurbo(this, 54, 28, textureX, textureY); // Box 4
		hardtackModel[4] = new ModelRendererTurbo(this, 54, 28, textureX, textureY); // Box 5

		hardtackModel[0].addShapeBox(-4F, -128F, -128F, 8, 256, 256, 0F, -3.5F, -126F, -126F, -3.5F, -126F, -126F, -3.5F, -126F, -126F, -3.5F, -126F, -126F, -3.5F, -126F, -126F, -3.5F, -126F, -126F, -3.5F, -126F, -126F, -3.5F, -126F, -126F); // Box 0
		hardtackModel[0].setRotationPoint(0F, 0F, 0F);

		hardtackModel[1].addShapeBox(-0.5F, -2.25F, -2F, 1, 1, 4, 0F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F); // Box 1
		hardtackModel[1].setRotationPoint(0F, 0F, 0F);

		hardtackModel[2].addShapeBox(-0.5F, 1.25F, -2F, 1, 1, 4, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F); // Box 2
		hardtackModel[2].setRotationPoint(0F, 0F, 0F);

		hardtackModel[3].addShapeBox(-0.5F, -2F, -2.75F, 1, 4, 1, 0F, 0F, -0.25F, -0.5F, 0F, -0.25F, -0.5F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, -0.25F, -0.5F, 0F, -0.25F, -0.5F, 0F, 0F, -0.25F, 0F, 0F, -0.25F); // Box 4
		hardtackModel[3].setRotationPoint(0F, 0F, 0F);

		hardtackModel[4].addShapeBox(-0.5F, -2F, 1.75F, 1, 4, 1, 0F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, -0.25F, -0.5F, 0F, -0.25F, -0.5F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, -0.25F, -0.5F, 0F, -0.25F, -0.5F); // Box 5
		hardtackModel[4].setRotationPoint(0F, 0F, 0F);


	}

	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
	{
		for(int i = 0; i < 5; i++)
		{
			hardtackModel[i].render(f5);
		}
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5)
	{
	}

	public ModelRendererTurbo hardtackModel[];
}