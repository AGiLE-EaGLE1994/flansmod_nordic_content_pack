//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: CaroleanMusket
// Model Creator: 
// Created on: 11.03.2020 - 11:22:09
// Last changed on: 11.03.2020 - 11:22:09

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelCaroleanMusket extends ModelGun //Same as Filename
{
	int textureX = 128;
	int textureY = 64;

	public ModelCaroleanMusket() //Same as Filename
	{
		gunModel = new ModelRendererTurbo[11];
		defaultBarrelModel = new ModelRendererTurbo[5];
		defaultStockModel = new ModelRendererTurbo[2];
		ammoModel = new ModelRendererTurbo[1];
		leverActionModel = new ModelRendererTurbo[4];

		initgunModel_1();
		initdefaultBarrelModel_1();
		initdefaultStockModel_1();
		initammoModel_1();
		initleverActionModel_1();

		gripAttachPoint = new Vector3f(-18 /16F, 15F /16F, 0F /16F);


		itemFrameOffset = new Vector3f(0 /16F, -6F /16F, -9F /16F);


		gunSlideDistance = 4F;


		animationType = EnumAnimationType.END_LOADED;

		translateAll(0F, 0F, 0F);


		flipAll();
	}

	private void initgunModel_1()
	{
		gunModel[0] = new ModelRendererTurbo(this, 31, 24, textureX, textureY); // Import Box3
		gunModel[1] = new ModelRendererTurbo(this, 36, 19, textureX, textureY); // Import Box21
		gunModel[2] = new ModelRendererTurbo(this, 32, 19, textureX, textureY); // Import Box23
		gunModel[3] = new ModelRendererTurbo(this, 0, 11, textureX, textureY); // Box 59
		gunModel[4] = new ModelRendererTurbo(this, 1, 29, textureX, textureY); // Box 60
		gunModel[5] = new ModelRendererTurbo(this, 1, 29, textureX, textureY); // Box 62
		gunModel[6] = new ModelRendererTurbo(this, 0, 2, textureX, textureY); // Box 63
		gunModel[7] = new ModelRendererTurbo(this, 1, 29, textureX, textureY); // Box 67
		gunModel[8] = new ModelRendererTurbo(this, 1, 29, textureX, textureY); // Box 68
		gunModel[9] = new ModelRendererTurbo(this, 36, 19, textureX, textureY); // Box 23
		gunModel[10] = new ModelRendererTurbo(this, 36, 19, textureX, textureY); // Box 24

		gunModel[0].addShapeBox(-2.25F, -3.25F, -1.5F, 7, 4, 3, 0F,0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.5F, -0.75F, 0F, -0.5F, -0.75F, 0F, -0.5F, -0.75F, 0F, -0.5F, -0.75F); // Import Box3
		gunModel[0].setRotationPoint(0F, 0F, 0F);

		gunModel[1].addShapeBox(1F, 0.25F, -0.5F, 1, 2, 1, 0F,-0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F); // Import Box21
		gunModel[1].setRotationPoint(0F, 0F, 0F);

		gunModel[2].addShapeBox(-2F, 1.5F, -1.5F, 5, 1, 3, 0F,-0.25F, 0F, -1.25F, -1.5F, 0F, -1.25F, -1.5F, 0F, -1.25F, -0.25F, 0F, -1.25F, -0.25F, -0.5F, -1.25F, -1.5F, -0.5F, -1.25F, -1.5F, -0.5F, -1.25F, -0.25F, -0.5F, -1.25F); // Import Box23
		gunModel[2].setRotationPoint(0F, 0F, 0F);

		gunModel[3].addShapeBox(-6F, -5.25F, -1.25F, 16, 9, 1, 0F,-5F, -2.5F, 0F, -5F, -2.5F, 0F, -5F, -2.5F, 0F, -5F, -2.5F, 0F, -4F, -4F, 0F, -4F, -4F, 0F, -4F, -4F, 0F, -4F, -4F, 0F); // Box 59
		gunModel[3].setRotationPoint(0F, 0F, 0F);

		gunModel[4].addShapeBox(-1F, -1.5F, -2.25F, 2, 1, 1, 0F,-0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -0.5F, 0F, -1F, -0.5F, 0F, -1F, 0F, 0F, 0F, 0F, 0F); // Box 60
		gunModel[4].setRotationPoint(0F, 0F, 0F);

		gunModel[5].addShapeBox(3F, -1.5F, -2.25F, 2, 1, 1, 0F,0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.75F, 0F, -1F, -0.75F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F); // Box 62
		gunModel[5].setRotationPoint(0F, 0F, 0F);

		gunModel[6].addShapeBox(3F, -3.5F, -2.25F, 1, 2, 1, 0F,-0.75F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -0.75F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F); // Box 63
		gunModel[6].setRotationPoint(0F, 0F, 0F);

		gunModel[7].addShapeBox(3F, -1F, -2.25F, 2, 1, 1, 0F,-0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F); // Box 67
		gunModel[7].setRotationPoint(0F, 0F, 0F);

		gunModel[8].addShapeBox(3F, -0.75F, -2.25F, 2, 1, 1, 0F,-0.5F, -0.25F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.25F, 0F, -0.5F, -0.5F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.5F, 0F); // Box 68
		gunModel[8].setRotationPoint(0F, 0F, 0F);

		gunModel[9].addShapeBox(-2.5F, 0.25F, -0.5F, 1, 2, 1, 0F,-0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F); // Box 23
		gunModel[9].setRotationPoint(0F, 0F, 0F);

		gunModel[10].addShapeBox(-0.5F, 0.25F, -0.5F, 1, 2, 1, 0F,-0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, 0F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F, -0.75F); // Box 24
		gunModel[10].setRotationPoint(0F, 0F, 0F);
		gunModel[10].rotateAngleY = -0.01745329F;
		gunModel[10].rotateAngleZ = 0.13962634F;
	}

	private void initdefaultBarrelModel_1()
	{
		defaultBarrelModel[0] = new ModelRendererTurbo(this, 16, 22, textureX, textureY); // Import Box17
		defaultBarrelModel[1] = new ModelRendererTurbo(this, 2, 3, textureX, textureY); // Box 53
		defaultBarrelModel[2] = new ModelRendererTurbo(this, 1, 22, textureX, textureY); // Box 54
		defaultBarrelModel[3] = new ModelRendererTurbo(this, 0, 61, textureX, textureY); // Box 55
		defaultBarrelModel[4] = new ModelRendererTurbo(this, 44, 11, textureX, textureY); // Box 58

		defaultBarrelModel[0].addShapeBox(6F, -3.25F, -1.5F, 4, 4, 3, 0F,0F, 0F, -0.4F, 0F, 0F, -0.4F, 0F, 0F, -0.4F, 0F, 0F, -0.4F, 0F, -0.25F, -0.4F, 0F, -0.25F, -0.4F, 0F, -0.25F, -0.4F, 0F, -0.25F, -0.4F); // Import Box17
		defaultBarrelModel[0].setRotationPoint(0F, 0F, 0F);

		defaultBarrelModel[1].addShapeBox(4.75F, -2.75F, -1.5F, 48, 4, 3, 0F,0F, -0.25F, -0.75F, -22F, -0.5F, -1F, -22F, -0.5F, -1F, 0F, -0.25F, -0.75F, 0F, -1F, -0.75F, -22F, -2F, -1F, -22F, -2F, -1F, 0F, -1F, -0.75F); // Box 53
		defaultBarrelModel[1].setRotationPoint(0F, 0F, 0F);

		defaultBarrelModel[2].addShapeBox(21F, -3.35F, -1.5F, 4, 3, 3, 0F,0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F, 0F, 0F, -0.75F); // Box 54
		defaultBarrelModel[2].setRotationPoint(0F, 0F, 0F);

		defaultBarrelModel[3].addShapeBox(-2F, -3F, -0.5F, 53, 1, 1, 0F,0F, 0F, 0F, -16F, 0F, 0F, -16F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -16F, 0F, 0F, -16F, 0F, 0F, 0F, 0F, 0F); // Box 55
		defaultBarrelModel[3].setRotationPoint(0F, 0F, 0F);

		defaultBarrelModel[4].addShapeBox(27.5F, -2.35F, -1F, 4, 2, 2, 0F,0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0.5F, 0F, -0.25F, -0.5F, 0F, -0.25F, -0.5F, 0F, -0.25F, 0.5F, 0F, -0.25F); // Box 58
		defaultBarrelModel[4].setRotationPoint(0F, 0F, 0F);
	}

	private void initdefaultStockModel_1()
	{
		defaultStockModel[0] = new ModelRendererTurbo(this, 1, 46, textureX, textureY); // Import Box4
		defaultStockModel[1] = new ModelRendererTurbo(this, 1, 32, textureX, textureY); // Box 52

		defaultStockModel[0].addShapeBox(-21.5F, -6.25F, -1F, 22, 11, 2, 0F,0F, -6F, -0.5F, -7F, -6F, -0.5F, -7F, -6F, -0.5F, 0F, -6F, -0.5F, 0F, 0F, -0.5F, -18F, 0F, -0.5F, -18F, 0F, -0.5F, 0F, 0F, -0.5F); // Import Box4
		defaultStockModel[0].setRotationPoint(0F, 0F, 0F);

		defaultStockModel[1].addShapeBox(-15.5F, -2.25F, -1F, 20, 7, 2, 0F,-13.25F, 0F, -0.5F, -6.75F, -2.5F, -0.5F, -6.75F, -2.5F, -0.5F, -13.25F, 0F, -0.5F, 2F, 0F, -0.5F, -19.5F, 0F, -0.5F, -19.5F, 0F, -0.5F, 2F, 0F, -0.5F); // Box 52
		defaultStockModel[1].setRotationPoint(0F, 0F, 0F);
	}

	private void initammoModel_1()
	{
		ammoModel[0] = new ModelRendererTurbo(this, 0, 59, textureX, textureY); // Box 57

		ammoModel[0].addShapeBox(3F, -1.75F, -0.5F, 32, 1, 1, 0F,0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, -0.25F); // Box 57
		ammoModel[0].setRotationPoint(0F, 0F, 0F);
	}

	private void initleverActionModel_1()
	{
		leverActionModel[0] = new ModelRendererTurbo(this, 0, 3, textureX, textureY); // Box 61
		leverActionModel[1] = new ModelRendererTurbo(this, 0, 3, textureX, textureY); // Box 64
		leverActionModel[2] = new ModelRendererTurbo(this, 0, 3, textureX, textureY); // Box 65
		leverActionModel[3] = new ModelRendererTurbo(this, 0, 3, textureX, textureY); // Box 66

		leverActionModel[0].addShapeBox(0F, -2.5F, -2.25F, 1, 1, 1, 0F,-0.5F, 0F, -0.25F, -0.25F, -0.25F, -0.25F, -0.25F, -0.25F, -0.25F, -0.5F, 0F, -0.25F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 61
		leverActionModel[0].setRotationPoint(0F, 0F, 0F);

		leverActionModel[1].addShapeBox(-0.5F, -3F, -2.25F, 1, 1, 1, 0F,0F, 0F, -0.25F, 0F, -0.5F, -0.25F, 0F, -0.5F, -0.25F, 0F, 0F, -0.25F, 0F, -0.5F, -0.25F, -0.25F, 0F, -0.25F, -0.25F, 0F, -0.25F, 0F, -0.5F, -0.25F); // Box 64
		leverActionModel[1].setRotationPoint(0F, 0F, 0F);

		leverActionModel[2].addShapeBox(-0.5F, -4F, -2.25F, 1, 1, 1, 0F,0F, -0.99F, -0.25F, -0.5F, -0.75F, -0.25F, -0.5F, -0.75F, -0.25F, 0F, -0.99F, -0.25F, 0F, 0F, -0.25F, -0.5F, 0.25F, -0.25F, -0.5F, 0.25F, -0.25F, 0F, 0F, -0.25F); // Box 65
		leverActionModel[2].setRotationPoint(0F, 0F, 0F);

		leverActionModel[3].addShapeBox(-0.5F, -4F, -2.25F, 1, 1, 1, 0F,0F, -0.5F, -0.25F, 0F, 0F, -0.25F, 0F, 0F, -0.25F, 0F, -0.5F, -0.25F, 0F, 0F, -0.25F, 0.25F, -0.5F, -0.25F, 0.25F, -0.5F, -0.25F, 0F, 0F, -0.25F); // Box 66
		leverActionModel[3].setRotationPoint(0F, 0F, 0F);
	}
}