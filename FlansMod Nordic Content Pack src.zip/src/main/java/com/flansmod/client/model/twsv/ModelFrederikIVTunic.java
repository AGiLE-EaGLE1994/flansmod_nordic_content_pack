//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: FrederikIVTunic
// Model Creator: 
// Created on: 10.03.2020 - 11:17:29
// Last changed on: 10.03.2020 - 11:17:29

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.ModelCustomArmour;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelFrederikIVTunic extends ModelCustomArmour //Same as Filename
{
	int textureX = 64;
	int textureY = 64;

	public ModelFrederikIVTunic() //Same as Filename
	{
		bodyModel = new ModelRendererTurbo[4];
		bodyModel[0] = new ModelRendererTurbo(this, 0, 15, textureX, textureY); // torso
		bodyModel[1] = new ModelRendererTurbo(this, 19, 0, textureX, textureY); // Box 5
		bodyModel[2] = new ModelRendererTurbo(this, 26, 21, textureX, textureY); // Box 6
		bodyModel[3] = new ModelRendererTurbo(this, 23, 47, textureX, textureY); // Box 6

		bodyModel[0].addShapeBox(-4F, -0.1F, -2F, 8, 12, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // torso
		bodyModel[0].setRotationPoint(0F, 0F, 0F);

		bodyModel[1].addShapeBox(-6F, -0.5F, -3F, 12, 8, 6, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, -5F, 0F, -1F, -5F, 0F, -1F, -5F, 0F, -1F, -5F, 0F); // Box 5
		bodyModel[1].setRotationPoint(0F, 0F, 0F);

		bodyModel[2].addShapeBox(1F, 4.5F, -3F, 2, 8, 0, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 5.25F, -2F, -0.75F, -7.25F, 0F, -0.75F, -7.25F, 0F, 0.75F, 5.25F, -2F, 0.75F); // Box 6
		bodyModel[2].setRotationPoint(0F, 0F, 0F);

		bodyModel[3].addShapeBox(-6F, 2.5F, -3F, 12, 8, 6, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -3F, -6F, 0F, -3F, -6F, 0F, -3F, -6F, 0F, -3F, -6F, 0F); // Box 6
		bodyModel[3].setRotationPoint(0F, 0F, 0F);


		leftArmModel = new ModelRendererTurbo[1];
		leftArmModel[0] = new ModelRendererTurbo(this, 32, 15, textureX, textureY); // Box 9

		leftArmModel[0].addBox(-1F, -2F, -2F, 4, 9, 4, 0F); // Box 9
		leftArmModel[0].setRotationPoint(0F, 0F, 0F);


		rightArmModel = new ModelRendererTurbo[1];
		rightArmModel[0] = new ModelRendererTurbo(this, 32, 28, textureX, textureY); // Box 8

		rightArmModel[0].addBox(-3F, -2F, -2F, 4, 9, 4, 0F); // Box 8
		rightArmModel[0].setRotationPoint(0F, 0F, 0F);


	}
}