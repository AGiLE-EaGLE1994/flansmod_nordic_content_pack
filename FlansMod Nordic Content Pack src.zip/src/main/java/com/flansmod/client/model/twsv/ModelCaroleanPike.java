//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: CaroleanPike
// Model Creator: 
// Created on: 14.04.2020 - 11:23:12
// Last changed on: 14.04.2020 - 11:23:12

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelCaroleanPike extends ModelGun //Same as Filename
{
	int textureX = 32;
	int textureY = 64;

	public ModelCaroleanPike() //Same as Filename
	{
		gunModel = new ModelRendererTurbo[5];
		gunModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 0
		gunModel[1] = new ModelRendererTurbo(this, 4, 9, textureX, textureY); // Box 1
		gunModel[2] = new ModelRendererTurbo(this, 4, 0, textureX, textureY); // Box 2
		gunModel[3] = new ModelRendererTurbo(this, 4, 22, textureX, textureY); // Box 3
		gunModel[4] = new ModelRendererTurbo(this, 4, 18, textureX, textureY); // Box 4

		gunModel[0].addBox(-0.5F, -42F, -0.5F, 1, 64, 1, 0F); // Box 0
		gunModel[0].setRotationPoint(0F, 0F, 0F);
		gunModel[0].rotateAngleX = -0.01745329F;
		gunModel[0].rotateAngleY = -0.05235988F;

		gunModel[1].addShapeBox(-2F, -53F, -0.5F, 2, 8, 1, 0F, -1.99F, 0F, -0.49F, 0F, 0F, -0.49F, 0F, 0F, -0.49F, -1.99F, 0F, -0.49F, 0F, 0F, -0.49F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.49F); // Box 1
		gunModel[1].setRotationPoint(0F, 0F, 0F);

		gunModel[2].addShapeBox(0F, -53F, -0.5F, 2, 8, 1, 0F, 0F, 0F, -0.49F, -1.99F, 0F, -0.49F, -1.99F, 0F, -0.49F, 0F, 0F, -0.49F, 0F, 0F, 0F, 0F, 0F, -0.49F, 0F, 0F, -0.49F, 0F, 0F, 0F); // Box 2
		gunModel[2].setRotationPoint(0F, 0F, 0F);

		gunModel[3].addShapeBox(0F, -45F, -0.5F, 2, 3, 1, 0F, 0F, 0F, 0F, 0F, 0F, -0.49F, 0F, 0F, -0.49F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, 0F, 0F, 0F); // Box 3
		gunModel[3].setRotationPoint(0F, 0F, 0F);

		gunModel[4].addShapeBox(-2F, -45F, -0.5F, 2, 3, 1, 0F, 0F, 0F, -0.49F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.49F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, 0F, 0F); // Box 4
		gunModel[4].setRotationPoint(0F, 0F, 0F);

		translateAll(0F, 0F, 0F);


		flipAll();
	}
}