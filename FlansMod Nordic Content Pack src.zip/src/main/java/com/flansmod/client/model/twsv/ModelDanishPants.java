//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: DanishPants
// Model Creator: 
// Created on: 10.03.2020 - 11:17:29
// Last changed on: 10.03.2020 - 11:17:29

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.ModelCustomArmour;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelDanishPants extends ModelCustomArmour //Same as Filename
{
	int textureX = 32;
	int textureY = 32;

	public ModelDanishPants() //Same as Filename
	{
		leftLegModel = new ModelRendererTurbo[1];
		rightLegModel = new ModelRendererTurbo[3];

		initleftLegModel_1();
		initrightLegModel_1();
	}

	private void initleftLegModel_1()
	{
		leftLegModel[0] = new ModelRendererTurbo(this, 0, 14, textureX, textureY); // Box 9

		leftLegModel[0].addShapeBox(-2F, -0.199999999999999F, -2.5F, 4, 5, 5, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 1.25F, 0F, 0F, 1.25F, 0F, 2F, -2F, 0F, 2F); // Box 9
		leftLegModel[0].setRotationPoint(0F, 0F, 0F);
	}

	private void initrightLegModel_1()
	{
		rightLegModel[0] = new ModelRendererTurbo(this, 14, 22, textureX, textureY); // Box 8
		rightLegModel[1] = new ModelRendererTurbo(this, 1, 0, textureX, textureY); // Box 10
		rightLegModel[2] = new ModelRendererTurbo(this, 1, 0, textureX, textureY); // Box 11

		rightLegModel[0].addShapeBox(-2F, -0.199999999999999F, -2.5F, 4, 5, 5, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 1.25F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 2F, 1.25F, 0F, 2F); // Box 8
		rightLegModel[0].setRotationPoint(0F, 0F, 0F);

		rightLegModel[1].addShapeBox(-2F, -0.199999999999999F, -2F, 4, 8, 4, 0F,-0.19F, 0F, -0.05F, 0F, 0F, -0.05F, 0F, 0F, -0.05F, -0.19F, 0F, -0.05F, -0.19F, 0F, -0.05F, 0F, 0F, -0.05F, 0F, 0F, -0.05F, -0.19F, 0F, -0.05F); // Box 10
		rightLegModel[1].setRotationPoint(0F, 0F, 0F);

		rightLegModel[2].addShapeBox(2F, -0.199999999999999F, -2F, 4, 8, 4, 0F,0F, 0F, -0.05F, -0.19F, 0F, -0.05F, -0.19F, 0F, -0.05F, 0F, 0F, -0.05F, 0F, 0F, -0.05F, -0.19F, 0F, -0.05F, -0.19F, 0F, -0.05F, 0F, 0F, -0.05F); // Box 11
		rightLegModel[2].setRotationPoint(0F, 0F, 0F);
	}
}