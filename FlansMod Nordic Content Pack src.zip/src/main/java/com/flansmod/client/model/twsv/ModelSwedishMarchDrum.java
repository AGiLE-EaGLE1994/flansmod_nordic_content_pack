//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: SwedishMarchDrum
// Model Creator: 
// Created on: 25.04.2020 - 17:39:28
// Last changed on: 25.04.2020 - 17:39:28

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelSwedishMarchDrum extends ModelGun //Same as Filename
{
	int textureX = 512;
	int textureY = 512;

	public ModelSwedishMarchDrum() //Same as Filename
	{
		gunModel = new ModelRendererTurbo[14];
		gunModel[0] = new ModelRendererTurbo(this, 6, 4, textureX, textureY); // Box 0
		gunModel[1] = new ModelRendererTurbo(this, 6, 137, textureX, textureY); // Box 1
		gunModel[2] = new ModelRendererTurbo(this, 5, 240, textureX, textureY); // Box 2
		gunModel[3] = new ModelRendererTurbo(this, 2, 11, textureX, textureY); // Box 4
		gunModel[4] = new ModelRendererTurbo(this, 2, 16, textureX, textureY); // Box 5
		gunModel[5] = new ModelRendererTurbo(this, 0, 21, textureX, textureY); // Box 6
		gunModel[6] = new ModelRendererTurbo(this, 2, 1, textureX, textureY); // Box 8
		gunModel[7] = new ModelRendererTurbo(this, 2, 1, textureX, textureY); // Box 9
		gunModel[8] = new ModelRendererTurbo(this, 2, 1, textureX, textureY); // Box 10
		gunModel[9] = new ModelRendererTurbo(this, 2, 1, textureX, textureY); // Box 11
		gunModel[10] = new ModelRendererTurbo(this, 2, 1, textureX, textureY); // Box 12
		gunModel[11] = new ModelRendererTurbo(this, 2, 1, textureX, textureY); // Box 13
		gunModel[12] = new ModelRendererTurbo(this, 2, 1, textureX, textureY); // Box 14
		gunModel[13] = new ModelRendererTurbo(this, 2, 1, textureX, textureY); // Box 15

		gunModel[0].addShapeBox(-32F, -27F, -37F, 64, 64, 64, 0F, -28F, -28F, -30F, -28F, -28F, -30F, -28F, -28F, -30F, -28F, -28F, -30F, -28F, -30F, -30F, -28F, -30F, -30F, -28F, -30F, -30F, -28F, -30F, -30F); // Box 0
		gunModel[0].setRotationPoint(0F, 0F, 0F);

		gunModel[1].addShapeBox(-32F, -27F, -17F, 64, 64, 32, 0F, -28F, -28F, -14F, -28F, -28F, -14F, -30F, -28F, -16F, -30F, -28F, -16F, -28F, -30F, -14F, -28F, -30F, -14F, -30F, -30F, -16F, -30F, -30F, -16F); // Box 1
		gunModel[1].setRotationPoint(0F, 0F, 0F);

		gunModel[2].addShapeBox(-32F, -27F, -25F, 64, 64, 32, 0F, -30F, -28F, -16F, -30F, -28F, -16F, -28F, -28F, -14F, -28F, -28F, -14F, -30F, -30F, -16F, -30F, -30F, -16F, -28F, -30F, -14F, -28F, -30F, -14F); // Box 2
		gunModel[2].setRotationPoint(0F, 0F, 0F);

		gunModel[3].addShapeBox(-4F, 0.75F, -3F, 8, 2, 2, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, -2F, 0F, 0.25F, -2F, 0F, 0.25F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, -2F, 0F, 0.25F, -2F, 0F, 0.25F); // Box 4
		gunModel[3].setRotationPoint(0F, 0F, 0F);

		gunModel[4].addShapeBox(-4F, 0.75F, -9F, 8, 2, 2, 0F, -2F, 0F, 0.25F, -2F, 0F, 0.25F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, -2F, 0F, 0.25F, -2F, 0F, 0.25F, 0.25F, 0F, 0F, 0.25F, 0F, 0F); // Box 5
		gunModel[4].setRotationPoint(0F, 0F, 0F);

		gunModel[5].addShapeBox(-4F, 0.75F, -7F, 8, 2, 4, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F, 0.25F, 0F, 0F); // Box 6
		gunModel[5].setRotationPoint(0F, 0F, 0F);

		gunModel[6].addShapeBox(-2.5F, 2.75F, -1.7F, 1, 6, 1, 0F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F); // Box 8
		gunModel[6].setRotationPoint(0F, 0F, 0F);

		gunModel[7].addShapeBox(1.5F, 2.75F, -1.7F, 1, 6, 1, 0F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F); // Box 9
		gunModel[7].setRotationPoint(0F, 0F, 0F);

		gunModel[8].addShapeBox(1.5F, 2.75F, -9.4F, 1, 6, 1, 0F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F); // Box 10
		gunModel[8].setRotationPoint(0F, 0F, 0F);

		gunModel[9].addShapeBox(-2.5F, 2.75F, -9.4F, 1, 6, 1, 0F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F); // Box 11
		gunModel[9].setRotationPoint(0F, 0F, 0F);

		gunModel[10].addShapeBox(3.25F, 2.75F, -7.5F, 1, 6, 1, 0F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F); // Box 12
		gunModel[10].setRotationPoint(0F, 0F, 0F);

		gunModel[11].addShapeBox(3.25F, 2.75F, -3.5F, 1, 6, 1, 0F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F); // Box 13
		gunModel[11].setRotationPoint(0F, 0F, 0F);

		gunModel[12].addShapeBox(-4.25F, 2.75F, -3.5F, 1, 6, 1, 0F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F); // Box 14
		gunModel[12].setRotationPoint(0F, 0F, 0F);

		gunModel[13].addShapeBox(-4.25F, 2.75F, -7.5F, 1, 6, 1, 0F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, 0F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F, -0.2F, -1.7F, -0.2F); // Box 15
		gunModel[13].setRotationPoint(0F, 0F, 0F);



		translateAll(0F, 0F, 0F);


		flipAll();
	}
}