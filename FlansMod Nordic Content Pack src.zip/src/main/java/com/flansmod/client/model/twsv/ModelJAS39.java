//This File was created with the Minecraft-SMP Modelling Toolbox 2.3.0.0
// Copyright (C) 2020 Minecraft-SMP.de
// This file is for Flan's Flying Mod Version 4.0.x+

// Model: JAS39
// Model Creator: 
// Created on: 15.05.2018 - 12:06:36
// Last changed on: 15.05.2018 - 12:06:36

package com.flansmod.client.model.twsv; //Path where the model is located

import com.flansmod.client.model.ModelPlane;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelJAS39 extends ModelPlane //Same as Filename
{
	int textureX = 512;
	int textureY = 512;

	public ModelJAS39() //Same as Filename
	{
		bodyModel = new ModelRendererTurbo[27];
		noseModel = new ModelRendererTurbo[4];
		tailModel = new ModelRendererTurbo[12];
		leftWingModel = new ModelRendererTurbo[15];
		rightWingModel = new ModelRendererTurbo[13];
		topWingModel = new ModelRendererTurbo[2];
		yawFlapModel = new ModelRendererTurbo[1];
		pitchFlapLeftModel = new ModelRendererTurbo[1];
		pitchFlapRightModel = new ModelRendererTurbo[1];
		pitchFlapLeftWingModel = new ModelRendererTurbo[1];
		pitchFlapRightWingModel = new ModelRendererTurbo[1];
		bodyDoorCloseModel = new ModelRendererTurbo[4];
		skidsModel = new ModelRendererTurbo[15];

		initbodyModel_1();
		initnoseModel_1();
		inittailModel_1();
		initleftWingModel_1();
		initrightWingModel_1();
		inittopWingModel_1();
		inityawFlapModel_1();
		initpitchFlapLeftModel_1();
		initpitchFlapRightModel_1();
		initpitchFlapLeftWingModel_1();
		initpitchFlapRightWingModel_1();
		initbodyDoorCloseModel_1();
		initskidsModel_1();

		initPropeller();

		translateAll(0F, 0F, 0F);


		flipAll();
	}

	private void initbodyModel_1()
	{
		bodyModel[0] = new ModelRendererTurbo(this, 111, 279, textureX, textureY); // Import Box39
		bodyModel[1] = new ModelRendererTurbo(this, 1, 208, textureX, textureY); // Import CockpitPanel
		bodyModel[2] = new ModelRendererTurbo(this, 195, 164, textureX, textureY); // Import FuseFloor
		bodyModel[3] = new ModelRendererTurbo(this, 43, 44, textureX, textureY); // Import FuseWallRight
		bodyModel[4] = new ModelRendererTurbo(this, 63, 8, textureX, textureY); // Import SeatTop
		bodyModel[5] = new ModelRendererTurbo(this, 221, 262, textureX, textureY); // Import Box68
		bodyModel[6] = new ModelRendererTurbo(this, 1, 54, textureX, textureY); // Import Box40
		bodyModel[7] = new ModelRendererTurbo(this, 195, 189, textureX, textureY); // Box 47
		bodyModel[8] = new ModelRendererTurbo(this, 0, 44, textureX, textureY); // Box 48
		bodyModel[9] = new ModelRendererTurbo(this, 64, 54, textureX, textureY); // Box 51
		bodyModel[10] = new ModelRendererTurbo(this, 70, 86, textureX, textureY); // Box 52
		bodyModel[11] = new ModelRendererTurbo(this, 123, 122, textureX, textureY); // Box 53
		bodyModel[12] = new ModelRendererTurbo(this, 0, 19, textureX, textureY); // Box 54
		bodyModel[13] = new ModelRendererTurbo(this, 2, 133, textureX, textureY); // Box 55
		bodyModel[14] = new ModelRendererTurbo(this, 208, 145, textureX, textureY); // Box 56
		bodyModel[15] = new ModelRendererTurbo(this, 104, 185, textureX, textureY); // Box 57
		bodyModel[16] = new ModelRendererTurbo(this, 3, 94, textureX, textureY); // Box 58
		bodyModel[17] = new ModelRendererTurbo(this, 106, 168, textureX, textureY); // Box 59
		bodyModel[18] = new ModelRendererTurbo(this, 116, 145, textureX, textureY); // Box 60
		bodyModel[19] = new ModelRendererTurbo(this, 111, 265, textureX, textureY); // Box 61
		bodyModel[20] = new ModelRendererTurbo(this, 1, 279, textureX, textureY); // Box 62
		bodyModel[21] = new ModelRendererTurbo(this, 1, 264, textureX, textureY); // Box 64
		bodyModel[22] = new ModelRendererTurbo(this, 0, 9, textureX, textureY); // Box 78
		bodyModel[23] = new ModelRendererTurbo(this, 1, 166, textureX, textureY); // Box 79
		bodyModel[24] = new ModelRendererTurbo(this, 37, 30, textureX, textureY); // Box 80
		bodyModel[25] = new ModelRendererTurbo(this, 0, 30, textureX, textureY); // Box 81
		bodyModel[26] = new ModelRendererTurbo(this, 136, 40, textureX, textureY); // Box 82

		bodyModel[0].addShapeBox(0F, 0F, 0F, 49, 7, 5, 0F,0F, -2F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, 1F, 1F, 0F, 0F, 2F); // Import Box39
		bodyModel[0].setRotationPoint(24F, -27.5F, 0F);

		bodyModel[1].addShapeBox(0F, 0F, 0F, 13, 17, 24, 0F,-6F, -6.5F, -9F, -3F, -5.5F, -9F, -3F, -5.5F, -9.5F, -6F, -6.5F, -9.5F, -6F, -6F, -9F, -3F, -6F, -9F, -3F, -6F, -9.5F, -6F, -6F, -9.5F); // Import CockpitPanel
		bodyModel[1].setRotationPoint(-54F, -30.5F, -12F);

		bodyModel[2].addShapeBox(0F, 0F, 0F, 33, 16, 7, 0F,0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -11F, -3F, 0F, -11F, -2F, 0F, -10F, 0F, 0F, -10F, 0F); // Import FuseFloor
		bodyModel[2].setRotationPoint(-61F, -16.5F, -7F);

		bodyModel[3].addShapeBox(0F, 0F, 2F, 20, 8, 1, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F); // Import FuseWallRight
		bodyModel[3].setRotationPoint(-48F, -24.5F, 2F);

		bodyModel[4].addBox(0F, 0F, 0F, 3, 15, 6, 0F); // Import SeatTop
		bodyModel[4].setRotationPoint(-36F, -27.5F, -3F);

		bodyModel[5].addShapeBox(0F, 0F, 0F, 36, 11, 7, 0F,2F, -1F, 0F, 0F, 3F, 0F, 0F, 0F, -1.5F, 0F, -1F, -2F, 0F, -2F, 0F, 0F, -1F, 0F, 0F, -4F, -0.5F, -2F, -3F, -2F); // Import Box68
		bodyModel[5].setRotationPoint(-38F, -21.5F, 5F);

		bodyModel[6].addShapeBox(0F, 0F, 0F, 15, 15, 16, 0F,-13F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -14F, -13F, 0F, -14F, -13F, -12F, 0F, -1F, -12F, 0F, -1F, -12F, -14F, -13F, -12F, -14F); // Import Box40
		bodyModel[6].setRotationPoint(-57F, -25F, -1.25F);

		bodyModel[7].addShapeBox(0F, 0F, 0F, 33, 16, 7, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, -10F, 0F, 0F, -10F, 0F, 0F, -11F, -2F, 0F, -11F, -3F); // Box 47
		bodyModel[7].setRotationPoint(-61F, -16.5F, 0F);

		bodyModel[8].addShapeBox(0F, 0F, 2F, 20, 8, 1, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0.5F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 48
		bodyModel[8].setRotationPoint(-48F, -24.5F, -7F);

		bodyModel[9].addShapeBox(0F, 0F, 0F, 26, 24, 7, 0F,0F, 0F, 0F, 0F, 1F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, -10F, 0F, 0F, -10F, 0F, 0F, -11F, -2F, 0F, -11F, -2F); // Box 51
		bodyModel[9].setRotationPoint(-28F, -24.5F, 0F);

		bodyModel[10].addShapeBox(0F, 0F, 0F, 26, 24, 7, 0F,0F, 0F, -2F, 0F, 0F, -2F, 0F, 1F, 0F, 0F, 0F, 0F, 0F, -11F, -2F, 0F, -11F, -2F, 0F, -10F, 0F, 0F, -10F, 0F); // Box 52
		bodyModel[10].setRotationPoint(-28F, -24.5F, -7F);

		bodyModel[11].addShapeBox(0F, 0F, 0F, 36, 11, 7, 0F,0F, -1F, -2F, 0F, 0F, -1.5F, 0F, 3F, 0F, 2F, -1F, 0F, -2F, -3F, -2F, 0F, -4F, -0.5F, 0F, -1F, 0F, 0F, -2F, 0F); // Box 53
		bodyModel[11].setRotationPoint(-38F, -21.5F, -12F);

		bodyModel[12].addShapeBox(0F, 0F, 0F, 26, 5, 5, 0F,0F, -1F, -2F, 0F, -4F, -4F, 0F, -4F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -4F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 54
		bodyModel[12].setRotationPoint(-28F, -29.5F, -5F);

		bodyModel[13].addShapeBox(0F, 0F, 0F, 26, 24, 7, 0F,0F, 0F, -2F, 0F, 0F, -2F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -11F, -2F, 0F, -11F, -2F, 0F, -11F, 0F, 0F, -10F, 0F); // Box 55
		bodyModel[13].setRotationPoint(-2F, -24.5F, -7F);

		bodyModel[14].addShapeBox(0F, 0F, 0F, 26, 11, 6, 0F,0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 3F, 0F, 0F, 3F, 0F, 0F, -4F, 0.5F, 0F, -6F, 0F, 0F, -1F, 0F, 0F, -1F, 0F); // Box 56
		bodyModel[14].setRotationPoint(-2F, -21.5F, -11F);

		bodyModel[15].addShapeBox(0F, 0F, 0F, 26, 11, 6, 0F,0F, 3F, 0F, 0F, 3F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -6F, 0F, 0F, -4F, 0.5F); // Box 57
		bodyModel[15].setRotationPoint(-2F, -21.5F, 5F);

		bodyModel[16].addShapeBox(0F, 0F, 0F, 26, 24, 7, 0F,0F, 1F, 0F, 0F, 1F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, -10F, 0F, 0F, -11F, 0F, 0F, -11F, -2F, 0F, -11F, -2F); // Box 58
		bodyModel[16].setRotationPoint(-2F, -24.5F, 0F);

		bodyModel[17].addShapeBox(0F, 0F, 0F, 36, 9, 6, 0F,0F, 0F, 0F, 0F, -2F, 0F, 13F, -2F, -1F, 0F, 3F, 0F, 0F, -4F, 0F, 0F, -6.99F, 0F, 13F, -6.99F, -1F, 0F, 1F, 0F); // Box 59
		bodyModel[17].setRotationPoint(24F, -21.5F, -11F);

		bodyModel[18].addShapeBox(0F, 0F, 0F, 36, 9, 6, 0F,0F, 3F, 0F, 13F, -2F, -1F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 13F, -6.99F, -1F, 0F, -6.99F, 0F, 0F, -4F, 0F); // Box 60
		bodyModel[18].setRotationPoint(24F, -21.5F, 5F);

		bodyModel[19].addShapeBox(0F, 0F, 0F, 49, 7, 5, 0F,0F, -3F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 2F, 0F, 1F, 1F, 0F, 1F, 0F, 0F, 0F, 0F); // Box 61
		bodyModel[19].setRotationPoint(24F, -27.5F, -5F);

		bodyModel[20].addShapeBox(0F, 0F, 0F, 49, 8, 5, 0F,0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -5F, -1F, 0F, -4F, 0F, 0F, 0F, 0F); // Box 62
		bodyModel[20].setRotationPoint(24F, -19.5F, -5F);

		bodyModel[21].addShapeBox(0F, 0F, 0F, 49, 8, 5, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -4F, 0F, 0F, -5F, -1F, 0F, 0F, 0F); // Box 64
		bodyModel[21].setRotationPoint(24F, -19.5F, 0F);

		bodyModel[22].addShapeBox(0F, 0F, 0F, 26, 5, 5, 0F,0F, 0F, 0F, 0F, -4F, 0F, 0F, -4F, -4F, 0F, -1F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -4F, 0F, 0F, 0F); // Box 78
		bodyModel[22].setRotationPoint(-28F, -29.5F, 0F);

		bodyModel[23].addShapeBox(0F, 0F, 0F, 13, 17, 24, 0F,-6F, -4F, -11F, -3F, -4F, -11F, -3F, -4F, -11F, -6F, -4F, -11F, -6F, -10F, -11F, -3F, -10F, -11F, -3F, -10F, -11F, -6F, -10F, -11F); // Box 79
		bodyModel[23].setRotationPoint(-54F, -23.5F, -12F);

		bodyModel[24].addShapeBox(0F, 0F, 0F, 13, 8, 5, 0F,0F, -4F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 80
		bodyModel[24].setRotationPoint(-61F, -24.5F, -5F);

		bodyModel[25].addShapeBox(0F, 0F, 0F, 13, 8, 5, 0F,0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -4F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 81
		bodyModel[25].setRotationPoint(-61F, -24.5F, 0F);

		bodyModel[26].addBox(0F, 0F, 0F, 5, 7, 8, 0F); // Box 82
		bodyModel[26].setRotationPoint(-33F, -23.5F, -4F);
	}

	private void initnoseModel_1()
	{
		noseModel[0] = new ModelRendererTurbo(this, 143, 294, textureX, textureY); // Box 43
		noseModel[1] = new ModelRendererTurbo(this, 71, 294, textureX, textureY); // Box 44
		noseModel[2] = new ModelRendererTurbo(this, 0, 294, textureX, textureY); // Box 45
		noseModel[3] = new ModelRendererTurbo(this, 3, 251, textureX, textureY); // Box 46

		noseModel[0].addShapeBox(0F, 0F, 0F, 30, 5, 5, 0F,0F, -8.99F, -4.99F, 0F, -1F, -1F, 0F, 0F, 0F, 0F, -8.99F, 0F, 0F, 4F, -4.99F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 4F, 0F); // Box 43
		noseModel[0].setRotationPoint(-91F, -21.5F, -5F);

		noseModel[1].addShapeBox(0F, 0F, 0F, 30, 5, 5, 0F,0F, -3.99F, -4.99F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3.99F, 0F, 0F, -1F, -4.99F, 0F, 0F, -1F, 0F, 1F, 0F, 0F, -1F, 0F); // Box 44
		noseModel[1].setRotationPoint(-91F, -16.5F, -5F);

		noseModel[2].addShapeBox(0F, 0F, 0F, 30, 5, 5, 0F,0F, -8.99F, 0F, 0F, 0F, 0F, 0F, -1F, -1F, 0F, -8.99F, -4.99F, 0F, 4F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 4F, -4.99F); // Box 45
		noseModel[2].setRotationPoint(-91F, -21.5F, 0F);

		noseModel[3].addShapeBox(0F, 0F, 0F, 30, 5, 5, 0F,0F, -3.99F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3.99F, -4.99F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 0F, -1F, 0F, -1F, -4.99F); // Box 46
		noseModel[3].setRotationPoint(-91F, -16.5F, 0F);
	}

	private void inittailModel_1()
	{
		tailModel[0] = new ModelRendererTurbo(this, 77, 176, textureX, textureY); // Import NozzleUp
		tailModel[1] = new ModelRendererTurbo(this, 78, 164, textureX, textureY); // Box 65
		tailModel[2] = new ModelRendererTurbo(this, 121, 18, textureX, textureY); // Box 66
		tailModel[3] = new ModelRendererTurbo(this, 130, 81, textureX, textureY); // Box 67
		tailModel[4] = new ModelRendererTurbo(this, 121, 33, textureX, textureY); // Box 68
		tailModel[5] = new ModelRendererTurbo(this, 77, 189, textureX, textureY); // Box 69
		tailModel[6] = new ModelRendererTurbo(this, 52, 165, textureX, textureY); // Box 70
		tailModel[7] = new ModelRendererTurbo(this, 52, 174, textureX, textureY); // Box 71
		tailModel[8] = new ModelRendererTurbo(this, 65, 312, textureX, textureY); // Box 96
		tailModel[9] = new ModelRendererTurbo(this, 42, 321, textureX, textureY); // Box 99
		tailModel[10] = new ModelRendererTurbo(this, 67, 322, textureX, textureY); // Box 101
		tailModel[11] = new ModelRendererTurbo(this, 42, 313, textureX, textureY); // Box 102

		tailModel[0].addShapeBox(0F, 0F, 0F, 7, 7, 5, 0F,0F, -1F, -1F, 0F, -3F, -2F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F); // Import NozzleUp
		tailModel[0].setRotationPoint(78F, -26.5F, -5F);

		tailModel[1].addShapeBox(0F, 0F, 0F, 5, 4, 6, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -4F, 0F, -1F, -2F); // Box 65
		tailModel[1].setRotationPoint(73F, -19.5F, 0F);

		tailModel[2].addShapeBox(0F, 0F, 0F, 5, 8, 6, 0F,0F, 0F, 0F, 0F, -1F, 0F, 0F, -2F, -2F, 0F, -2F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 66
		tailModel[2].setRotationPoint(73F, -27.5F, 0F);

		tailModel[3].addShapeBox(0F, 0F, 0F, 5, 4, 6, 0F,0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -2F, 0F, -1F, -4F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 67
		tailModel[3].setRotationPoint(73F, -19.5F, -6F);

		tailModel[4].addShapeBox(0F, 0F, 0F, 5, 8, 6, 0F,0F, -2F, -1F, 0F, -2F, -2F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 68
		tailModel[4].setRotationPoint(73F, -27.5F, -6F);

		tailModel[5].addShapeBox(0F, 0F, 0F, 7, 7, 5, 0F,0F, 0F, 0F, 0F, -2F, 0F, 0F, -3F, -2F, 0F, -1F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F); // Box 69
		tailModel[5].setRotationPoint(78F, -26.5F, 0F);

		tailModel[6].addShapeBox(0F, 0F, 0F, 7, 3, 5, 0F,0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, -1F, -3F, 0F, -1F, 0F, 0F, 1F, 0F); // Box 70
		tailModel[6].setRotationPoint(78F, -19.5F, -5F);

		tailModel[7].addShapeBox(0F, 0F, 0F, 7, 3, 5, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F, -1F, -3F, 0F, 0F, -3F); // Box 71
		tailModel[7].setRotationPoint(78F, -19.5F, 0F);

		tailModel[8].addShapeBox(0F, 0F, 0F, 7, 4, 4, 0F,0F, -1F, 0F, -1F, -1F, -1F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, -1F, -1F, 0F, 0F, 0F, 0F, 0F); // Box 96
		tailModel[8].setRotationPoint(78F, -24.5F, -4F);

		tailModel[9].addShapeBox(0F, 0F, 0F, 7, 4, 4, 0F,0F, 0F, 0F, -1F, 0F, 0F, -1F, -1F, -1F, 0F, -1F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, -1F, 0F, 0F, 0F); // Box 99
		tailModel[9].setRotationPoint(78F, -24.5F, 0F);

		tailModel[10].addShapeBox(0F, 0F, 0F, 7, 3, 4, 0F,0F, 0F, 0F, -1F, 0F, -1F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -1F, 0F, -2F, -1F, 0F, 0F, 0F, 1F, 0F); // Box 101
		tailModel[10].setRotationPoint(78F, -20.5F, -4F);

		tailModel[11].addShapeBox(0F, 0F, 0F, 7, 3, 4, 0F,0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, -1F, 0F, 0F, 0F, 0F, 1F, 0F, -1F, 0F, 0F, -1F, 0F, -2F, 0F, 0F, -1F); // Box 102
		tailModel[11].setRotationPoint(78F, -20.5F, 0F);
	}

	private void initleftWingModel_1()
	{
		leftWingModel[0] = new ModelRendererTurbo(this, 80, 204, textureX, textureY); // Shape 72
		leftWingModel[1] = new ModelRendererTurbo(this, 212, 126, textureX, textureY); // Shape 73
		leftWingModel[2] = new ModelRendererTurbo(this, 86, 9, textureX, textureY); // Shape 95
		leftWingModel[3] = new ModelRendererTurbo(this, 139, 114, textureX, textureY); // Box 96
		leftWingModel[4] = new ModelRendererTurbo(this, 197, 238, textureX, textureY); // Box 74
		leftWingModel[5] = new ModelRendererTurbo(this, 214, 217, textureX, textureY); // Box 76
		leftWingModel[6] = new ModelRendererTurbo(this, 2, 312, textureX, textureY); // Box 268
		leftWingModel[7] = new ModelRendererTurbo(this, 2, 305, textureX, textureY); // Box 269
		leftWingModel[8] = new ModelRendererTurbo(this, 16, 312, textureX, textureY); // Box 270
		leftWingModel[9] = new ModelRendererTurbo(this, 16, 312, textureX, textureY); // Box 271
		leftWingModel[10] = new ModelRendererTurbo(this, 191, 50, textureX, textureY); // Box 79
		leftWingModel[11] = new ModelRendererTurbo(this, 2, 312, textureX, textureY); // Box 80
		leftWingModel[12] = new ModelRendererTurbo(this, 2, 305, textureX, textureY); // Box 81
		leftWingModel[13] = new ModelRendererTurbo(this, 16, 312, textureX, textureY); // Box 82
		leftWingModel[14] = new ModelRendererTurbo(this, 16, 312, textureX, textureY); // Box 83

		leftWingModel[0].addShape3D(0F, 0F, -0.5F, new Shape2D(new Coord2D[] { new Coord2D(0, 26, 0, 26), new Coord2D(1, 0, 1, 0), new Coord2D(56, 0, 56, 0), new Coord2D(24, 26, 24, 26) }), 1, 56, 26, 148, 1, ModelRendererTurbo.MR_FRONT, new float[] {24 ,42 ,55 ,27}); // Shape 72
		leftWingModel[0].setRotationPoint(47F, -19.5F, -11F);
		leftWingModel[0].rotateAngleX = 1.57079633F;

		leftWingModel[1].addShape3D(0F, 0F, -0.5F, new Shape2D(new Coord2D[] { new Coord2D(0, 14, 0, 14), new Coord2D(1, 0, 1, 0), new Coord2D(29, 0, 29, 0), new Coord2D(8, 14, 8, 14) }), 1, 29, 14, 77, 1, ModelRendererTurbo.MR_FRONT, new float[] {8 ,26 ,28 ,15}); // Shape 73
		leftWingModel[1].setRotationPoint(48F, -19.5F, -37F);
		leftWingModel[1].rotateAngleX = 1.57079633F;

		leftWingModel[2].addShape3D(4F, -4F, 0F, new Shape2D(new Coord2D[] { new Coord2D(1, 7, 1, 7), new Coord2D(0, 4, 0, 4), new Coord2D(1, 1, 1, 1), new Coord2D(4, 0, 4, 0), new Coord2D(7, 1, 7, 1), new Coord2D(8, 4, 8, 4), new Coord2D(7, 7, 7, 7), new Coord2D(4, 8, 4, 8) }), 32, 8, 8, 32, 32, ModelRendererTurbo.MR_FRONT, new float[] {4 ,4 ,4 ,4 ,4 ,4 ,4 ,4}); // Shape 95
		leftWingModel[2].setRotationPoint(36F, -9F, -22.5F);
		leftWingModel[2].rotateAngleY = -1.57079633F;

		leftWingModel[3].addShapeBox(-21F, 0F, 0F, 24, 5, 1, 0F,-5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -5F, 0F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, 2F, 0F); // Box 96
		leftWingModel[3].setRotationPoint(32F, -19.5F, -23F);
		leftWingModel[3].rotateAngleZ = 0.01745329F;

		leftWingModel[4].addShapeBox(0.5F, -0.5F, -8F, 6, 1, 18, 0F,1F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F); // Box 74
		leftWingModel[4].setRotationPoint(47.5F, -19.5F, 41F);

		leftWingModel[5].addShapeBox(0.5F, -0.5F, -8F, 6, 1, 18, 0F,0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F); // Box 76
		leftWingModel[5].setRotationPoint(47.5F, -19.5F, -43F);

		leftWingModel[6].addShapeBox(-21F, -1.5F, -1.5F, 3, 3, 3, 0F,0F, -1.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, -1.5F, 0F, -1.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, -1.5F); // Box 268
		leftWingModel[6].setRotationPoint(23F, -15F, -17.5F);
		leftWingModel[6].rotateAngleX = 0.78539816F;

		leftWingModel[7].addShapeBox(-21F, -1.5F, -1.5F, 41, 3, 3, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 269
		leftWingModel[7].setRotationPoint(26F, -15F, -17.5F);
		leftWingModel[7].rotateAngleX = 0.78539816F;

		leftWingModel[8].addBox(-21F, -4.5F, 0F, 12, 9, 0, 0F); // Box 270
		leftWingModel[8].setRotationPoint(55F, -15F, -17.5F);
		leftWingModel[8].rotateAngleX = 0.78539816F;

		leftWingModel[9].addBox(-21F, -4.5F, 0F, 12, 9, 0, 0F); // Box 271
		leftWingModel[9].setRotationPoint(55F, -15F, -17.5F);
		leftWingModel[9].rotateAngleX = 5.49778714F;

		leftWingModel[10].addBox(-21F, 0F, -4F, 16, 1, 8, 0F); // Box 79
		leftWingModel[10].setRotationPoint(39F, -15.5F, -23F);
		leftWingModel[10].rotateAngleZ = 0.01745329F;

		leftWingModel[11].addShapeBox(-21F, -1.5F, -1.5F, 3, 3, 3, 0F,0F, -1.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, -1.5F, 0F, -1.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, -1.5F); // Box 80
		leftWingModel[11].setRotationPoint(23F, -15F, -28.5F);
		leftWingModel[11].rotateAngleX = 0.78539816F;

		leftWingModel[12].addShapeBox(-21F, -1.5F, -1.5F, 41, 3, 3, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 81
		leftWingModel[12].setRotationPoint(26F, -15F, -28.5F);
		leftWingModel[12].rotateAngleX = 0.78539816F;

		leftWingModel[13].addBox(-21F, -4.5F, 0F, 12, 9, 0, 0F); // Box 82
		leftWingModel[13].setRotationPoint(55F, -15F, -28.5F);
		leftWingModel[13].rotateAngleX = 5.49778714F;

		leftWingModel[14].addBox(-21F, -4.5F, 0F, 12, 9, 0, 0F); // Box 83
		leftWingModel[14].setRotationPoint(55F, -15F, -28.5F);
		leftWingModel[14].rotateAngleX = 0.78539816F;
	}

	private void initrightWingModel_1()
	{
		rightWingModel[0] = new ModelRendererTurbo(this, 139, 114, textureX, textureY); // Import pylonright
		rightWingModel[1] = new ModelRendererTurbo(this, 79, 234, textureX, textureY); // Shape 76
		rightWingModel[2] = new ModelRendererTurbo(this, 206, 108, textureX, textureY); // Shape 77
		rightWingModel[3] = new ModelRendererTurbo(this, 86, 9, textureX, textureY); // Shape 94
		rightWingModel[4] = new ModelRendererTurbo(this, 2, 312, textureX, textureY); // Box 84
		rightWingModel[5] = new ModelRendererTurbo(this, 2, 305, textureX, textureY); // Box 85
		rightWingModel[6] = new ModelRendererTurbo(this, 16, 312, textureX, textureY); // Box 86
		rightWingModel[7] = new ModelRendererTurbo(this, 16, 312, textureX, textureY); // Box 87
		rightWingModel[8] = new ModelRendererTurbo(this, 16, 312, textureX, textureY); // Box 88
		rightWingModel[9] = new ModelRendererTurbo(this, 16, 312, textureX, textureY); // Box 89
		rightWingModel[10] = new ModelRendererTurbo(this, 2, 305, textureX, textureY); // Box 90
		rightWingModel[11] = new ModelRendererTurbo(this, 2, 312, textureX, textureY); // Box 91
		rightWingModel[12] = new ModelRendererTurbo(this, 191, 50, textureX, textureY); // Box 92

		rightWingModel[0].addShapeBox(-21F, 0F, 0F, 24, 5, 1, 0F,-5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -5F, 0F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, 2F, 0F); // Import pylonright
		rightWingModel[0].setRotationPoint(32F, -19.5F, 22F);
		rightWingModel[0].rotateAngleZ = 0.01745329F;

		rightWingModel[1].addShape3D(0F, 0F, -0.5F, new Shape2D(new Coord2D[] { new Coord2D(0, 26, 0, 26), new Coord2D(1, 0, 1, 0), new Coord2D(56, 0, 56, 0), new Coord2D(24, 26, 24, 26) }), 1, 56, 26, 148, 1, ModelRendererTurbo.MR_FRONT, new float[] {24 ,42 ,55 ,27}); // Shape 76
		rightWingModel[1].setRotationPoint(47F, -19.5F, 11F);
		rightWingModel[1].rotateAngleX = -1.57079633F;

		rightWingModel[2].addShape3D(0F, 0F, -0.5F, new Shape2D(new Coord2D[] { new Coord2D(0, 14, 0, 14), new Coord2D(1, 0, 1, 0), new Coord2D(29, 0, 29, 0), new Coord2D(8, 14, 8, 14) }), 1, 29, 14, 77, 1, ModelRendererTurbo.MR_FRONT, new float[] {8 ,26 ,28 ,15}); // Shape 77
		rightWingModel[2].setRotationPoint(48F, -19.5F, 37F);
		rightWingModel[2].rotateAngleX = -1.57079633F;

		rightWingModel[3].addShape3D(4F, -4F, 0F, new Shape2D(new Coord2D[] { new Coord2D(1, 7, 1, 7), new Coord2D(0, 4, 0, 4), new Coord2D(1, 1, 1, 1), new Coord2D(4, 0, 4, 0), new Coord2D(7, 1, 7, 1), new Coord2D(8, 4, 8, 4), new Coord2D(7, 7, 7, 7), new Coord2D(4, 8, 4, 8) }), 32, 8, 8, 32, 32, ModelRendererTurbo.MR_FRONT, new float[] {4 ,4 ,4 ,4 ,4 ,4 ,4 ,4}); // Shape 94
		rightWingModel[3].setRotationPoint(36F, -9F, 22.5F);
		rightWingModel[3].rotateAngleY = -1.57079633F;

		rightWingModel[4].addShapeBox(-21F, -1.5F, -1.5F, 3, 3, 3, 0F,0F, -1.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, -1.5F, 0F, -1.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, -1.5F); // Box 84
		rightWingModel[4].setRotationPoint(23F, -15F, 16.5F);
		rightWingModel[4].rotateAngleX = 0.78539816F;

		rightWingModel[5].addShapeBox(-21F, -1.5F, -1.5F, 41, 3, 3, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 85
		rightWingModel[5].setRotationPoint(26F, -15F, 16.5F);
		rightWingModel[5].rotateAngleX = 0.78539816F;

		rightWingModel[6].addBox(-21F, -4.5F, 0F, 12, 9, 0, 0F); // Box 86
		rightWingModel[6].setRotationPoint(55F, -15F, 16.5F);
		rightWingModel[6].rotateAngleX = 5.49778714F;

		rightWingModel[7].addBox(-21F, -4.5F, 0F, 12, 9, 0, 0F); // Box 87
		rightWingModel[7].setRotationPoint(55F, -15F, 16.5F);
		rightWingModel[7].rotateAngleX = 0.78539816F;

		rightWingModel[8].addBox(-21F, -4.5F, 0F, 12, 9, 0, 0F); // Box 88
		rightWingModel[8].setRotationPoint(55F, -15F, 27.5F);
		rightWingModel[8].rotateAngleX = 5.49778714F;

		rightWingModel[9].addBox(-21F, -4.5F, 0F, 12, 9, 0, 0F); // Box 89
		rightWingModel[9].setRotationPoint(55F, -15F, 27.5F);
		rightWingModel[9].rotateAngleX = 0.78539816F;

		rightWingModel[10].addShapeBox(-21F, -1.5F, -1.5F, 41, 3, 3, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 90
		rightWingModel[10].setRotationPoint(26F, -15F, 27.5F);
		rightWingModel[10].rotateAngleX = 0.78539816F;

		rightWingModel[11].addShapeBox(-21F, -1.5F, -1.5F, 3, 3, 3, 0F,0F, -1.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, -1.5F, 0F, -1.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, -1.5F); // Box 91
		rightWingModel[11].setRotationPoint(23F, -15F, 27.5F);
		rightWingModel[11].rotateAngleX = 0.78539816F;

		rightWingModel[12].addBox(-21F, 0F, -4F, 16, 1, 8, 0F); // Box 92
		rightWingModel[12].setRotationPoint(39F, -15.5F, 22F);
		rightWingModel[12].rotateAngleZ = 0.01745329F;
	}

	private void inittopWingModel_1()
	{
		topWingModel[0] = new ModelRendererTurbo(this, 166, 22, textureX, textureY); // Shape 83
		topWingModel[1] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Shape 84

		topWingModel[0].addShape3D(0F, 0F, -0.5F, new Shape2D(new Coord2D[] { new Coord2D(0, 24, 0, 24), new Coord2D(0, 0, 0, 0), new Coord2D(44, 0, 44, 0), new Coord2D(11, 24, 11, 24) }), 1, 44, 24, 120, 1, ModelRendererTurbo.MR_FRONT, new float[] {11 ,41 ,44 ,24}); // Shape 83
		topWingModel[0].setRotationPoint(69F, -16.5F, 0F);

		topWingModel[1].addShape3D(0F, 0F, -0.5F, new Shape2D(new Coord2D[] { new Coord2D(0, 8, 0, 8), new Coord2D(0, 0, 0, 0), new Coord2D(16, 0, 16, 0), new Coord2D(6, 8, 6, 8) }), 1, 16, 8, 43, 1, ModelRendererTurbo.MR_FRONT, new float[] {6 ,13 ,16 ,8}); // Shape 84
		topWingModel[1].setRotationPoint(74F, -40.5F, 0F);
	}

	private void inityawFlapModel_1()
	{
		yawFlapModel[0] = new ModelRendererTurbo(this, 145, 22, textureX, textureY); // Box 85

		yawFlapModel[0].addShapeBox(0F, 0F, -0.5F, 5, 14, 1, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F); // Box 85
		yawFlapModel[0].setRotationPoint(69F, -40.5F, 0F);
	}

	private void initpitchFlapLeftModel_1()
	{
		pitchFlapLeftModel[0] = new ModelRendererTurbo(this, 166, 86, textureX, textureY); // Shape 74

		pitchFlapLeftModel[0].addShape3D(22F, 0F, -0.5F, new Shape2D(new Coord2D[] { new Coord2D(0, 19, 0, 19), new Coord2D(8, 0, 8, 0), new Coord2D(33, 0, 33, 0), new Coord2D(6, 19, 6, 19) }), 1, 33, 19, 86, 1, ModelRendererTurbo.MR_FRONT, new float[] {6 ,34 ,25 ,21}); // Shape 74
		pitchFlapLeftModel[0].setRotationPoint(-27F, -20.5F, -10F);
		pitchFlapLeftModel[0].rotateAngleX = 1.46607657F;
		pitchFlapLeftModel[0].rotateAngleZ = 0.05235988F;
	}

	private void initpitchFlapRightModel_1()
	{
		pitchFlapRightModel[0] = new ModelRendererTurbo(this, 166, 65, textureX, textureY); // Shape 75

		pitchFlapRightModel[0].addShape3D(22F, 0F, -0.5F, new Shape2D(new Coord2D[] { new Coord2D(0, 19, 0, 19), new Coord2D(8, 0, 8, 0), new Coord2D(33, 0, 33, 0), new Coord2D(6, 19, 6, 19) }), 1, 33, 19, 86, 1, ModelRendererTurbo.MR_FRONT, new float[] {6 ,34 ,25 ,21}); // Shape 75
		pitchFlapRightModel[0].setRotationPoint(-27F, -20.5F, 10F);
		pitchFlapRightModel[0].rotateAngleX = -1.46607657F;
		pitchFlapRightModel[0].rotateAngleZ = 0.05235988F;
	}

	private void initpitchFlapLeftWingModel_1()
	{
		pitchFlapLeftWingModel[0] = new ModelRendererTurbo(this, 255, 192, textureX, textureY); // Box 75

		pitchFlapLeftWingModel[0].addShapeBox(-0.5F, -0.5F, -12F, 12, 1, 23, 0F,-1F, 0F, 0F, -4F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, 0F, -1F, 0F, 0F, -4F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, 0F); // Box 75
		pitchFlapLeftWingModel[0].setRotationPoint(46.5F, -19.5F, -21F);
		pitchFlapLeftWingModel[0].rotateAngleY = 0.01745329F;
	}

	private void initpitchFlapRightWingModel_1()
	{
		pitchFlapRightWingModel[0] = new ModelRendererTurbo(this, 199, 286, textureX, textureY); // Box 73

		pitchFlapRightWingModel[0].addShapeBox(-0.5F, -0.5F, -12F, 12, 1, 23, 0F,0F, 0F, 0F, 0F, 0F, -0.5F, -4F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -4F, 0F, 0F, -1F, 0F, 0F); // Box 73
		pitchFlapRightWingModel[0].setRotationPoint(46.5F, -19.5F, 22F);
	}

	private void initbodyDoorCloseModel_1()
	{
		bodyDoorCloseModel[0] = new ModelRendererTurbo(this, 131, 56, textureX, textureY); // Import CanopyClosed
		bodyDoorCloseModel[1] = new ModelRendererTurbo(this, 137, 103, textureX, textureY); // Box 86
		bodyDoorCloseModel[2] = new ModelRendererTurbo(this, 137, 92, textureX, textureY); // Box 87
		bodyDoorCloseModel[3] = new ModelRendererTurbo(this, 131, 67, textureX, textureY); // Box 88

		bodyDoorCloseModel[0].addShapeBox(0F, 0F, 0F, 12, 5, 5, 0F,0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -2F, 0F, -1F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Import CanopyClosed
		bodyDoorCloseModel[0].setRotationPoint(-40F, -29.5F, 0F);
		bodyDoorCloseModel[0].rotateAngleY = -6.28318531F;

		bodyDoorCloseModel[1].addShapeBox(0F, 0F, 0F, 8, 5, 5, 0F,-3F, -3F, 0F, 0F, 0F, 0F, 0F, -1F, -1F, -3F, -3F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 86
		bodyDoorCloseModel[1].setRotationPoint(-48F, -29.5F, 0F);
		bodyDoorCloseModel[1].rotateAngleY = -6.28318531F;

		bodyDoorCloseModel[2].addShapeBox(0F, 0F, 0F, 8, 5, 5, 0F,-3F, -3F, -2F, 0F, -1F, -1F, 0F, 0F, 0F, -3F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 87
		bodyDoorCloseModel[2].setRotationPoint(-48F, -29.5F, -5F);
		bodyDoorCloseModel[2].rotateAngleY = -6.28318531F;

		bodyDoorCloseModel[3].addShapeBox(0F, 0F, 0F, 12, 5, 5, 0F,0F, -1F, -1F, 0F, -1F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 88
		bodyDoorCloseModel[3].setRotationPoint(-40F, -29.5F, -5F);
		bodyDoorCloseModel[3].rotateAngleY = -6.28318531F;
	}

	private void initskidsModel_1()
	{
		skidsModel[0] = new ModelRendererTurbo(this, 71, 125, textureX, textureY); // Import Box51
		skidsModel[1] = new ModelRendererTurbo(this, 83, 144, textureX, textureY); // Import g7
		skidsModel[2] = new ModelRendererTurbo(this, 88, 148, textureX, textureY); // Import g9
		skidsModel[3] = new ModelRendererTurbo(this, 166, 48, textureX, textureY); // Import Shape105
		skidsModel[4] = new ModelRendererTurbo(this, 89, 137, textureX, textureY); // Import Box42
		skidsModel[5] = new ModelRendererTurbo(this, 71, 137, textureX, textureY); // Import Box43
		skidsModel[6] = new ModelRendererTurbo(this, 84, 123, textureX, textureY); // Import Box44
		skidsModel[7] = new ModelRendererTurbo(this, 77, 139, textureX, textureY); // Import Box45
		skidsModel[8] = new ModelRendererTurbo(this, 82, 140, textureX, textureY); // Box 49
		skidsModel[9] = new ModelRendererTurbo(this, 71, 125, textureX, textureY); // Box 50
		skidsModel[10] = new ModelRendererTurbo(this, 121, 1, textureX, textureY); // Shape 89
		skidsModel[11] = new ModelRendererTurbo(this, 77, 139, textureX, textureY); // Box 90
		skidsModel[12] = new ModelRendererTurbo(this, 71, 137, textureX, textureY); // Box 91
		skidsModel[13] = new ModelRendererTurbo(this, 89, 137, textureX, textureY); // Box 92
		skidsModel[14] = new ModelRendererTurbo(this, 84, 123, textureX, textureY); // Box 93

		skidsModel[0].addBox(-2F, -2F, 0F, 4, 4, 2, 0F); // Import Box51
		skidsModel[0].setRotationPoint(-44F, 0F, 0.5F);

		skidsModel[1].addBox(0F, 0F, 0F, 1, 13, 1, 0F); // Import g7
		skidsModel[1].setRotationPoint(-45F, -12F, -0.5F);

		skidsModel[2].addBox(-0.5F, 0F, -0.5F, 1, 9, 1, 0F); // Import g9
		skidsModel[2].setRotationPoint(-49F, -11.5F, 0F);
		skidsModel[2].rotateAngleX = 0.54105207F;
		skidsModel[2].rotateAngleY = -1.57079633F;

		skidsModel[3].addShape3D(11F, -15F, 0F, new Shape2D(new Coord2D[] { new Coord2D(5, 0, 5, 0), new Coord2D(11, 0, 11, 0), new Coord2D(11, 15, 11, 15), new Coord2D(1, 15, 1, 15), new Coord2D(1, 7, 1, 7) }), 1, 11, 15, 48, 1, ModelRendererTurbo.MR_FRONT, new float[] {9 ,8 ,10 ,15 ,6}); // Import Shape105
		skidsModel[3].setRotationPoint(21F, -13.5F, 6F);
		skidsModel[3].rotateAngleZ = -1.57079633F;

		skidsModel[4].addBox(0F, 0F, 0F, 2, 2, 3, 0F); // Import Box42
		skidsModel[4].setRotationPoint(22F, -2.5F, 11F);

		skidsModel[5].addBox(0F, 0F, 0F, 1, 20, 1, 0F); // Import Box43
		skidsModel[5].setRotationPoint(23F, -21.5F, 9F);
		skidsModel[5].rotateAngleX = 0.13962634F;

		skidsModel[6].addBox(-3F, -3F, 0F, 6, 6, 2, 0F); // Import Box44
		skidsModel[6].setRotationPoint(23F, -1.5F, 13F);

		skidsModel[7].addBox(-0.5F, -1F, -0.5F, 1, 18, 1, 0F); // Import Box45
		skidsModel[7].setRotationPoint(9.5F, -13.5F, 5F);
		skidsModel[7].rotateAngleX = 1.11701072F;
		skidsModel[7].rotateAngleY = -1.11701072F;

		skidsModel[8].addBox(0F, 0F, 0F, 2, 1, 1, 0F); // Box 49
		skidsModel[8].setRotationPoint(-44F, 0F, -0.5F);

		skidsModel[9].addBox(-2F, -2F, 0F, 4, 4, 2, 0F); // Box 50
		skidsModel[9].setRotationPoint(-44F, 0F, -2.5F);

		skidsModel[10].addShape3D(11F, -15F, 0F, new Shape2D(new Coord2D[] { new Coord2D(5, 0, 5, 0), new Coord2D(11, 0, 11, 0), new Coord2D(11, 15, 11, 15), new Coord2D(1, 15, 1, 15), new Coord2D(1, 7, 1, 7) }), 1, 11, 15, 48, 1, ModelRendererTurbo.MR_FRONT, new float[] {9 ,8 ,10 ,15 ,6}); // Shape 89
		skidsModel[10].setRotationPoint(21F, -13.5F, -5F);
		skidsModel[10].rotateAngleZ = -1.55334303F;

		skidsModel[11].addBox(-0.5F, -1F, -0.5F, 1, 18, 1, 0F); // Box 90
		skidsModel[11].setRotationPoint(9.5F, -13.5F, -4.5F);
		skidsModel[11].rotateAngleX = -1.11701072F;
		skidsModel[11].rotateAngleY = 1.11701072F;

		skidsModel[12].addBox(0F, 0F, 0F, 1, 20, 1, 0F); // Box 91
		skidsModel[12].setRotationPoint(23F, -21.5F, -10F);
		skidsModel[12].rotateAngleX = -0.13962634F;

		skidsModel[13].addBox(0F, 0F, 0F, 2, 2, 3, 0F); // Box 92
		skidsModel[13].setRotationPoint(22F, -2.5F, -14F);

		skidsModel[14].addBox(-3F, -3F, 0F, 6, 6, 2, 0F); // Box 93
		skidsModel[14].setRotationPoint(23F, -1.5F, -15F);
	}

	private void initPropeller()
	{
		propellerModels = new ModelRendererTurbo[1][3];
		propellerModels[0] = makeProp1(0F, -23F, 0F);
	}

	private ModelRendererTurbo[] makeProp1(float i, float j, float k)
	{
		ModelRendererTurbo[] prop = new ModelRendererTurbo[3];
		prop[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY);
		prop[1] = new ModelRendererTurbo(this, 0, 0, textureX, textureY);
		prop[2] = new ModelRendererTurbo(this, 0, 0, textureX, textureY);
		prop[0].addBox(-0F, -1F, -0F, 0, 1, 0, 0.0F);
		prop[1].addBox(-0F, -1F, -0F, 0, 1, 0, 0.0F);
		prop[2].addBox(-0F, -1F, -0F, 0, 1, 0, 0.0F);
		prop[0].setRotationPoint(i, j, k);
		prop[1].setRotationPoint(i, j, k);
		prop[2].setRotationPoint(i, j, k);
		return prop;
	}
}